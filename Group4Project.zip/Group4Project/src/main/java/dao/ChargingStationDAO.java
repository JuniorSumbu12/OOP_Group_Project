package dao;

import model.ChargingStation;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for ChargingStation.
 * Handles database operations for charging stations (FR-04).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class ChargingStationDAO {
    private Connection connection;

    public ChargingStationDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Creates a new charging station.
     * @param station The ChargingStation to create
     * @return True if successful
     */
    public boolean createStation(ChargingStation station) {
        String insertSQL = "INSERT INTO charging_stations (station_id, name, building, latitude, longitude, max_capacity, chargers) " +
                          "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
            ps.setString(1, station.getStationId());
            ps.setString(2, station.getName());
            ps.setString(3, station.getBuilding());
            ps.setDouble(4, station.getLatitude());
            ps.setDouble(5, station.getLongitude());
            ps.setInt(6, station.getMaxCapacity());
            ps.setInt(7, station.getChargers());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creating charging station: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves all charging stations (FR-04).
     * @return List of all ChargingStation objects
     */
    public List<ChargingStation> getAllStations() {
        List<ChargingStation> stations = new ArrayList<>();
        String query = "SELECT * FROM charging_stations";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                ChargingStation station = new ChargingStation.ChargingStationBuilder(
                        rs.getString("station_id"),
                        rs.getString("name"),
                        rs.getDouble("latitude"),
                        rs.getDouble("longitude")
                    )
                    .building(rs.getString("building"))
                    .maxCapacity(rs.getInt("max_capacity"))
                    .chargers(rs.getInt("chargers"))
                    .build();

                stations.add(station);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving all stations: " + e.getMessage());
        }
        return stations;
    }

    /**
     * Retrieves charging station by ID.
     * @param station_id The station ID
     * @return ChargingStation or null if not found
     */
    public ChargingStation getStationById(String station_id) {
        String query = "SELECT * FROM charging_stations WHERE station_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, station_id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new ChargingStation.ChargingStationBuilder(
                        rs.getString("station_id"),
                        rs.getString("name"),
                        rs.getDouble("latitude"),
                        rs.getDouble("longitude")
                    )
                    .building(rs.getString("building"))
                    .maxCapacity(rs.getInt("max_capacity"))
                    .chargers(rs.getInt("chargers"))
                    .build();
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving station: " + e.getMessage());
        }
        return null;
    }

    /**
     * Updates station scooter count.
     * @param station_id The station ID
     * @param current_scooters Current number of scooters
     * @return True if successful
     */
    public boolean updateStationScooterCount(String station_id, Integer current_scooters) {
        String updateSQL = "UPDATE charging_stations SET current_scooters = ?, updated_date = CURRENT_TIMESTAMP WHERE station_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setInt(1, current_scooters);
            ps.setString(2, station_id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating station scooter count: " + e.getMessage());
            return false;
        }
    }

    /**
     * Gets available capacity at station.
     * @param station_id The station ID
     * @return Available slots
     */
    public Integer getAvailableCapacity(String station_id) {
        String query = "SELECT (max_capacity - current_scooters) as available FROM charging_stations WHERE station_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, station_id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("available");
            }
        } catch (SQLException e) {
            System.err.println("Error getting available capacity: " + e.getMessage());
        }
        return 0;
    }
}