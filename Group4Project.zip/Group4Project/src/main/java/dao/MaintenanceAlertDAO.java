package dao;

import model.MaintenanceAlert;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Data Access Object for MaintenanceAlert.
 * Handles database operations for alerts (FR-05).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class MaintenanceAlertDAO {
    private Connection connection;

    public MaintenanceAlertDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Creates alert with automatic validation (FR-05).
     * Uses builder pattern to validate alert data.
     * 
     * @param scooter_id ID of scooter requiring maintenance
     * @param alert_type Type of alert
     * @param severity Alert severity level
     * @param description Description of the issue
     * @return True if alert created successfully
     */
    public boolean createAlertWithBuilder(String scooter_id, String alert_type, String severity, String description) {
        try {
            // Builder validates severity and other fields automatically
            MaintenanceAlert alert = new MaintenanceAlert.MaintenanceAlertBuilder(
                    UUID.randomUUID().toString(),
                    scooter_id
                )
                .alertType(alert_type)
                .severity(severity)  // Validated by builder
                .description(description)
                .build();

            return persistAlert(alert);
        } catch (IllegalArgumentException e) {
            System.err.println("Validation error creating alert: " + e.getMessage());
            return false;
        }
    }

    /**
     * Persists alert to database (internal method).
     * @param alert The MaintenanceAlert to persist
     * @return True if persisted successfully
     */
    private boolean persistAlert(MaintenanceAlert alert) {
        String insertSQL = "INSERT INTO maintenance_alerts (alert_id, scooter_id, alert_type, severity, description, is_resolved) " +
                          "VALUES (?, ?, ?, ?, ?, FALSE)";

        try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
            ps.setString(1, alert.getAlertId());
            ps.setString(2, alert.getScooterId());
            ps.setString(3, alert.getAlertType());
            ps.setString(4, alert.getSeverity());
            ps.setString(5, alert.getDescription());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error persisting alert: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves all unresolved alerts (FR-05).
     * @return List of unresolved MaintenanceAlert objects
     */
    public List<MaintenanceAlert> getUnresolvedAlerts() {
        List<MaintenanceAlert> alerts = new ArrayList<>();
        String query = "SELECT * FROM maintenance_alerts WHERE is_resolved = FALSE ORDER BY created_date DESC";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                MaintenanceAlert alert = new MaintenanceAlert.MaintenanceAlertBuilder(
                        rs.getString("alert_id"),
                        rs.getString("scooter_id")
                    )
                    .alertType(rs.getString("alert_type"))
                    .severity(rs.getString("severity"))
                    .description(rs.getString("description"))
                    .isResolved(rs.getBoolean("is_resolved"))
                    .createdDate(rs.getString("created_date"))
                    .build();

                alerts.add(alert);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving unresolved alerts: " + e.getMessage());
        }
        return alerts;
    }

    /**
     * Retrieves all alerts for a specific scooter (FR-05).
     * @param scooter_id ID of the scooter
     * @return List of MaintenanceAlert objects
     */
    public List<MaintenanceAlert> getAlertsByScooter(String scooter_id) {
        List<MaintenanceAlert> alerts = new ArrayList<>();
        String query = "SELECT * FROM maintenance_alerts WHERE scooter_id = ? ORDER BY created_date DESC";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, scooter_id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                MaintenanceAlert alert = new MaintenanceAlert.MaintenanceAlertBuilder(
                        rs.getString("alert_id"),
                        rs.getString("scooter_id")
                    )
                    .alertType(rs.getString("alert_type"))
                    .severity(rs.getString("severity"))
                    .description(rs.getString("description"))
                    .build();

                alerts.add(alert);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving alerts: " + e.getMessage());
        }
        return alerts;
    }
 /**
     * Retrieves alerts by severity level.
     * @param severity Alert severity (LOW, MEDIUM, HIGH, CRITICAL)
     * @return List of alerts
     */
    public List<MaintenanceAlert> getAlertsBySeverity(String severity) {
        List<MaintenanceAlert> alerts = new ArrayList<>();
        String query = "SELECT * FROM maintenance_alerts WHERE severity = ? ORDER BY created_date DESC";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, severity);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                MaintenanceAlert alert = new MaintenanceAlert.MaintenanceAlertBuilder(
                        rs.getString("alert_id"),
                        rs.getString("scooter_id")
                    )
                    .alertType(rs.getString("alert_type"))
                    .severity(severity)
                    .description(rs.getString("description"))
                    .build();

                alerts.add(alert);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving alerts by severity: " + e.getMessage());
        }
        return alerts;
    }
    /**
     * Updates alert resolution status (FR-05).
     * @param alert_id The alert to update
     * @param is_resolved True if resolved
     * @return True if update successful
     */
    public boolean updateAlertStatus(String alert_id, Boolean is_resolved) {
        String updateSQL = "UPDATE maintenance_alerts SET is_resolved = ?, resolved_date = CURRENT_TIMESTAMP WHERE alert_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setBoolean(1, is_resolved);
            ps.setString(2, alert_id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating alert: " + e.getMessage());
            return false;
        }
    }
}