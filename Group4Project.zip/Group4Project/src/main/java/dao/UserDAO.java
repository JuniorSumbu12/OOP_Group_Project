package dao;

import model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for User.
 * Handles database operations for user authentication (FR-01).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class UserDAO {
    private Connection connection;

    public UserDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Creates a new user in database.
     * @param user The User to create
     * @return True if successful
     */
    public boolean createUser(User user) {
        String insertSQL = "INSERT INTO users (user_id, name, email, password_hash, user_type, credits, is_active) " +
                          "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
            ps.setString(1, user.getUserId());
            ps.setString(2, user.getName());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPasswordHash());
            ps.setString(5, user.getUserType());
            ps.setDouble(6, user.getCredits());
            ps.setBoolean(7, user.getIsActive());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creating user: " + e.getMessage());
            return false;
        }
    }

    /**
     * Authenticates user login (FR-01).
     * @param email User email
     * @param password User password
     * @return User if authenticated, null otherwise
     */
    public User authenticateUser(String email, String password) {
        String query = "SELECT * FROM users WHERE email = ? AND password_hash = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new User.UserBuilder(rs.getString("user_id"), rs.getString("email"))
                    .name(rs.getString("name"))
                    .passwordHash(rs.getString("password_hash"))
                    .userType(rs.getString("user_type"))
                    .credits(rs.getDouble("credits"))
                    .isActive(rs.getBoolean("is_active"))
                    .createdDate(rs.getString("created_date"))
                    .updatedDate(rs.getString("updated_date"))
                    .build();
            }
        } catch (SQLException e) {
            System.err.println("Error authenticating user: " + e.getMessage());
        }
        return null;
    }

    /**
     * Retrieves user by ID.
     * @param user_id The user ID
     * @return User or null if not found
     */
    public User getUserById(String user_id) {
        String query = "SELECT * FROM users WHERE user_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, user_id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new User.UserBuilder(rs.getString("user_id"), rs.getString("email"))
                    .name(rs.getString("name"))
                    .passwordHash(rs.getString("password_hash"))
                    .userType(rs.getString("user_type"))
                    .credits(rs.getDouble("credits"))
                    .isActive(rs.getBoolean("is_active"))
                    .build();
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving user: " + e.getMessage());
        }
        return null;
    }

    /**
     * Updates user credits.
     * @param user_id The user ID
     * @param credits New credit amount
     * @return True if successful
     */
    public boolean updateUserCredits(String user_id, Double credits) {
        String updateSQL = "UPDATE users SET credits = ?, updated_date = CURRENT_TIMESTAMP WHERE user_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setDouble(1, credits);
            ps.setString(2, user_id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating user credits: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves all users by type.
     * @param user_type Type of user (USER, SPONSOR, MAINTAINER)
     * @return List of users
     */
    public List<User> getUsersByType(String user_type) {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM users WHERE user_type = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, user_type);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                User user = new User.UserBuilder(rs.getString("user_id"), rs.getString("email"))
                    .name(rs.getString("name"))
                    .userType(user_type)
                    .credits(rs.getDouble("credits"))
                    .build();
                users.add(user);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving users by type: " + e.getMessage());
        }
        return users;
    }

    /**
     * Deactivates user account.
     * @param user_id The user ID
     * @return True if successful
     */
    public boolean deactivateUser(String user_id) {
        String updateSQL = "UPDATE users SET is_active = FALSE, updated_date = CURRENT_TIMESTAMP WHERE user_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setString(1, user_id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deactivating user: " + e.getMessage());
            return false;
        }
    }
}