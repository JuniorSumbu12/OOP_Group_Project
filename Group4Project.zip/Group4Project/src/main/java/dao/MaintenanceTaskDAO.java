package dao;

import model.MaintenanceTask;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for MaintenanceTask.
 * Handles database operations for maintenance tasks (FR-05).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class MaintenanceTaskDAO {
    private Connection connection;

    public MaintenanceTaskDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Creates a new maintenance task.
     * @param task The MaintenanceTask to create
     * @return True if successful
     */
    public boolean createTask(MaintenanceTask task) {
        String insertSQL = "INSERT INTO maintenance_tasks (task_id, scooter_id, maintainer_id, task_type, status, issue_description) " +
                          "VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
            ps.setString(1, task.getTaskId());
            ps.setString(2, task.getScooterId());
            ps.setString(3, task.getMaintainerId());
            ps.setString(4, task.getTaskType());
            ps.setString(5, task.getStatus());
            ps.setString(6, task.getIssueDescription());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creating maintenance task: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves task by ID.
     * @param task_id The task ID
     * @return MaintenanceTask or null if not found
     */
    public MaintenanceTask getTaskById(String task_id) {
        String query = "SELECT * FROM maintenance_tasks WHERE task_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, task_id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new MaintenanceTask.MaintenanceTaskBuilder(
                        rs.getString("task_id"),
                        rs.getString("scooter_id")
                    )
                    .maintainerId(rs.getString("maintainer_id"))
                    .taskType(rs.getString("task_type"))
                    .status(rs.getString("status"))
                    .issueDescription(rs.getString("issue_description"))
                    .build();
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving task: " + e.getMessage());
        }
        return null;
    }

    /**
     * Retrieves all pending tasks (FR-05).
     * @return List of pending MaintenanceTask objects
     */
    public List<MaintenanceTask> getPendingTasks() {
        List<MaintenanceTask> tasks = new ArrayList<>();
        String query = "SELECT * FROM maintenance_tasks WHERE status = 'PENDING' ORDER BY created_date ASC";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                MaintenanceTask task = new MaintenanceTask.MaintenanceTaskBuilder(
                        rs.getString("task_id"),
                        rs.getString("scooter_id")
                    )
                    .maintainerId(rs.getString("maintainer_id"))
                    .taskType(rs.getString("task_type"))
                    .status("PENDING")
                    .issueDescription(rs.getString("issue_description"))
                    .build();

                tasks.add(task);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving pending tasks: " + e.getMessage());
        }
        return tasks;
    }

    /**
     * Retrieves tasks assigned to a maintainer.
     * @param maintainer_id The maintainer ID
     * @return List of MaintenanceTask objects
     */
    public List<MaintenanceTask> getTasksByMaintainer(String maintainer_id) {
        List<MaintenanceTask> tasks = new ArrayList<>();
        String query = "SELECT * FROM maintenance_tasks WHERE maintainer_id = ? ORDER BY created_date DESC";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, maintainer_id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                MaintenanceTask task = new MaintenanceTask.MaintenanceTaskBuilder(
                        rs.getString("task_id"),
                        rs.getString("scooter_id")
                    )
                    .maintainerId(maintainer_id)
                    .taskType(rs.getString("task_type"))
                    .status(rs.getString("status"))
                    .issueDescription(rs.getString("issue_description"))
                    .build();

                tasks.add(task);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving tasks by maintainer: " + e.getMessage());
        }
        return tasks;
    }

    /**
     * Updates task status (FR-05).
     * @param task_id The task ID
     * @param status New status
     * @return True if successful
     */
    public boolean updateTaskStatus(String task_id, String status) {
        String updateSQL = "UPDATE maintenance_tasks SET status = ?, completed_date = CURRENT_TIMESTAMP WHERE task_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setString(1, status);
            ps.setString(2, task_id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating task status: " + e.getMessage());
            return false;
        }
    }

    /**
     * Assigns task to maintainer.
     * @param task_id The task ID
     * @param maintainer_id The maintainer ID
     * @return True if successful
     */
    public boolean assignTaskToMaintainer(String task_id, String maintainer_id) {
        String updateSQL = "UPDATE maintenance_tasks SET maintainer_id = ?, status = 'IN_PROGRESS' WHERE task_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setString(1, maintainer_id);
            ps.setString(2, task_id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error assigning task: " + e.getMessage());
            return false;
        }
    }
}