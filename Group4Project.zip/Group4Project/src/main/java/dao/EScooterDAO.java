package dao;

import model.EScooter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for EScooter.
 * Handles database operations for scooters (FR-02, FR-03, FR-04).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class EScooterDAO {
    private Connection connection;

    public EScooterDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Creates a new scooter in database.
     * @param scooter The EScooter to create
     * @return True if successful
     */
    public boolean createScooter(EScooter scooter) {
        String insertSQL = "INSERT INTO e_scooters (scooter_id, vehicle_number, make, model, " +
                          "color, battery_capacity, current_battery, status, current_station_id, " +
                          "wheel_condition, brake_condition, battery_health_percentage) " +
                          "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
            ps.setString(1, scooter.getScooterId());
            ps.setString(2, scooter.getVehicleNumber());
            ps.setString(3, scooter.getMake());
            ps.setString(4, scooter.getModel());
            ps.setString(5, scooter.getColor());
            ps.setDouble(6, scooter.getBatteryCapacity());
            ps.setDouble(7, scooter.getCurrentBattery());
            ps.setString(8, scooter.getStatus());
            ps.setString(9, scooter.getCurrentStationId());
            ps.setString(10, scooter.getWheelCondition());
            ps.setString(11, scooter.getBrakeCondition());
            ps.setInt(12, scooter.getBatteryHealthPercentage());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creating scooter: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves scooter as builder for modification (FR-02).
     * @param scooter_id The scooter ID
     * @return EScooterBuilder or null if not found
     */
    public EScooter.EScooterBuilder getScooterBuilderById(String scooter_id) {
        String query = "SELECT * FROM e_scooters WHERE scooter_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, scooter_id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new EScooter.EScooterBuilder(
                        rs.getString("scooter_id"),
                        rs.getString("vehicle_number"),
                        rs.getString("make"),
                        rs.getString("model")
                    )
                    .color(rs.getString("color"))
                    .batteryCapacity(rs.getDouble("battery_capacity"))
                    .currentBattery(rs.getDouble("current_battery"))
                    .status(rs.getString("status"))
                    .location(rs.getDouble("latitude"), rs.getDouble("longitude"))
                    .hoursUsed(rs.getDouble("hours_used"))
                    .wheelCondition(rs.getString("wheel_condition"))
                    .brakeCondition(rs.getString("brake_condition"))
                    .batteryHealthPercentage(rs.getInt("battery_health_percentage"))
                    .currentStationId(rs.getString("current_station_id"));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving scooter: " + e.getMessage());
        }
        return null;
    }

    /**
     * Retrieves complete scooter from database.
     * @param scooter_id The scooter ID
     * @return EScooter or null if not found
     */
    public EScooter getScooterById(String scooter_id) {
        EScooter.EScooterBuilder builder = getScooterBuilderById(scooter_id);
        if (builder != null) {
            return builder.build();
        }
        return null;
    }

    /**
     * Retrieves all scooters from database (FR-02).
     * @return List of all EScooter objects
     */
    public List<EScooter> getAllScooters() {
        List<EScooter> scooters = new ArrayList<>();
        String query = "SELECT * FROM e_scooters";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                EScooter scooter = new EScooter.EScooterBuilder(
                        rs.getString("scooter_id"),
                        rs.getString("vehicle_number"),
                        rs.getString("make"),
                        rs.getString("model")
                    )
                    .color(rs.getString("color"))
                    .batteryCapacity(rs.getDouble("battery_capacity"))
                    .currentBattery(rs.getDouble("current_battery"))
                    .status(rs.getString("status"))
                    .location(rs.getDouble("latitude"), rs.getDouble("longitude"))
                    .hoursUsed(rs.getDouble("hours_used"))
                    .wheelCondition(rs.getString("wheel_condition"))
                    .brakeCondition(rs.getString("brake_condition"))
                    .batteryHealthPercentage(rs.getInt("battery_health_percentage"))
                    .currentStationId(rs.getString("current_station_id"))
                    .build();

                scooters.add(scooter);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving all scooters: " + e.getMessage());
        }
        return scooters;
    }

    /**
     * Retrieves scooters filtered by status (FR-02).
     * @param status The status to filter by
     * @return List of scooters with specified status
     */
    public List<EScooter> getScootersByStatus(String status) {
        List<EScooter> scooters = new ArrayList<>();
        String query = "SELECT * FROM e_scooters WHERE status = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, status);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                EScooter scooter = new EScooter.EScooterBuilder(
                        rs.getString("scooter_id"),
                        rs.getString("vehicle_number"),
                        rs.getString("make"),
                        rs.getString("model")
                    )
                    .status(status)
                    .build();

                scooters.add(scooter);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving scooters by status: " + e.getMessage());
        }
        return scooters;
    }

    /**
     * Updates scooter GPS location (FR-03).
     * @param scooter_id The scooter to update
     * @param latitude New latitude
     * @param longitude New longitude
     * @return True if successful
     */
    public boolean updateScooterLocation(String scooter_id, Double latitude, Double longitude) {
        String updateSQL = "UPDATE e_scooters SET latitude = ?, longitude = ?, updated_date = CURRENT_TIMESTAMP WHERE scooter_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setDouble(1, latitude);
            ps.setDouble(2, longitude);
            ps.setString(3, scooter_id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating scooter location: " + e.getMessage());
            return false;
        }
    }

    /**
     * Updates scooter battery level (FR-04).
     * @param scooter_id The scooter to update
     * @param current_battery New battery percentage
     * @param battery_health New health percentage
     * @return True if successful
     */
    public boolean updateScooterBattery(String scooter_id, Double current_battery, Integer battery_health) {
        String updateSQL = "UPDATE e_scooters SET current_battery = ?, battery_health_percentage = ?, " +
                          "updated_date = CURRENT_TIMESTAMP WHERE scooter_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setDouble(1, current_battery);
            ps.setInt(2, battery_health);
            ps.setString(3, scooter_id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating scooter battery: " + e.getMessage());
            return false;
        }
    }

    /**
     * Updates scooter status (FR-02).
     * @param scooter_id The scooter to update
     * @param status New status
     * @return True if successful
     */
    public boolean updateScooterStatus(String scooter_id, String status) {
        String updateSQL = "UPDATE e_scooters SET status = ?, updated_date = CURRENT_TIMESTAMP WHERE scooter_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setString(1, status);
            ps.setString(2, scooter_id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating scooter status: " + e.getMessage());
            return false;
        }
    }
}