package dao;

import model.Maintainer;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Maintainer.
 * Handles database operations for maintainers (FR-05).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class MaintainerDAO {
    private Connection connection;

    public MaintainerDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Creates a new maintainer.
     * @param maintainer The Maintainer to create
     * @return True if successful
     */
    public boolean createMaintainer(Maintainer maintainer) {
        String insertSQL = "INSERT INTO maintainers (user_id, specialization, certification, availability_status, tasks_completed) " +
                          "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
            ps.setString(1, maintainer.getUserId());
            ps.setString(2, maintainer.getSpecialization());
            ps.setString(3, maintainer.getCertification());
            ps.setString(4, maintainer.getAvailabilityStatus());
            ps.setInt(5, maintainer.getTasksCompleted());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creating maintainer: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves maintainer by user ID.
     * @param user_id The user ID
     * @return Maintainer or null if not found
     */
    public Maintainer getMaintainerById(String user_id) {
        String query = "SELECT * FROM maintainers WHERE user_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, user_id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Maintainer.MaintainerBuilder(rs.getString("user_id"))
                    .specialization(rs.getString("specialization"))
                    .certification(rs.getString("certification"))
                    .availabilityStatus(rs.getString("availability_status"))
                    .tasksCompleted(rs.getInt("tasks_completed"))
                    .build();
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving maintainer: " + e.getMessage());
        }
        return null;
    }

    /**
     * Retrieves all available maintainers (FR-05).
     * @return List of available maintainers
     */
    public List<Maintainer> getAvailableMaintainers() {
        List<Maintainer> maintainers = new ArrayList<>();
        String query = "SELECT * FROM maintainers WHERE availability_status = 'AVAILABLE'";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Maintainer maintainer = new Maintainer.MaintainerBuilder(rs.getString("user_id"))
                    .specialization(rs.getString("specialization"))
                    .certification(rs.getString("certification"))
                    .availabilityStatus("AVAILABLE")
                    .tasksCompleted(rs.getInt("tasks_completed"))
                    .build();

                maintainers.add(maintainer);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving available maintainers: " + e.getMessage());
        }
        return maintainers;
    }

    /**
     * Updates maintainer availability status.
     * @param user_id The maintainer user ID
     * @param availability_status New status
     * @return True if successful
     */
    public boolean updateAvailabilityStatus(String user_id, String availability_status) {
        String updateSQL = "UPDATE maintainers SET availability_status = ?, updated_date = CURRENT_TIMESTAMP WHERE user_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setString(1, availability_status);
            ps.setString(2, user_id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating maintainer status: " + e.getMessage());
            return false;
        }
    }

    /**
     * Increments tasks completed count.
     * @param user_id The maintainer user ID
     * @return True if successful
     */
    public boolean incrementTasksCompleted(String user_id) {
        String updateSQL = "UPDATE maintainers SET tasks_completed = tasks_completed + 1, updated_date = CURRENT_TIMESTAMP WHERE user_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setString(1, user_id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error incrementing tasks completed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Gets total tasks completed by all maintainers.
     * @return Total tasks
     */
    public Integer getTotalTasksCompleted() {
        String query = "SELECT SUM(tasks_completed) as total FROM maintainers";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            System.err.println("Error calculating total tasks: " + e.getMessage());
        }
        return 0;
    }
}