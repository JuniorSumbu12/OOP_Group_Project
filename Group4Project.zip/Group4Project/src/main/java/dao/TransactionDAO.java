package dao;

import model.Transaction;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Transaction.
 * Handles database operations for financial transactions (FR-06).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class TransactionDAO {
    private Connection connection;

    public TransactionDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Creates a new transaction.
     * @param transaction The Transaction to create
     * @return True if successful
     */
    public boolean createTransaction(Transaction transaction) {
        String insertSQL = "INSERT INTO transactions (transaction_id, user_id, scooter_id, transaction_type, amount, category, description) " +
                          "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
            ps.setString(1, transaction.getTransactionId());
            ps.setString(2, transaction.getUserId());
            ps.setString(3, transaction.getScooterId());
            ps.setString(4, transaction.getTransactionType());
            ps.setDouble(5, transaction.getAmount());
            ps.setString(6, transaction.getCategory());
            ps.setString(7, transaction.getDescription());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creating transaction: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves transactions by user (FR-06).
     * @param user_id The user ID
     * @return List of transactions
     */
    public List<Transaction> getTransactionsByUser(String user_id) {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM transactions WHERE user_id = ? ORDER BY created_date DESC";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, user_id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Transaction transaction = new Transaction.TransactionBuilder(
                        rs.getString("transaction_id"),
                        rs.getString("user_id"),
                        rs.getString("transaction_type"),
                        rs.getDouble("amount")
                    )
                    .scooterId(rs.getString("scooter_id"))
                    .category(rs.getString("category"))
                    .description(rs.getString("description"))
                    .createdDate(rs.getString("created_date"))
                    .build();

                transactions.add(transaction);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving transactions: " + e.getMessage());
        }
        return transactions;
    }

    /**
     * Retrieves transaction by ID.
     * @param transaction_id The transaction ID
     * @return Transaction or null if not found
     */
    public Transaction getTransactionById(String transaction_id) {
        String query = "SELECT * FROM transactions WHERE transaction_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, transaction_id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Transaction.TransactionBuilder(
                        rs.getString("transaction_id"),
                        rs.getString("user_id"),
                        rs.getString("transaction_type"),
                        rs.getDouble("amount")
                    )
                    .scooterId(rs.getString("scooter_id"))
                    .category(rs.getString("category"))
                    .description(rs.getString("description"))
                    .build();
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving transaction: " + e.getMessage());
        }
        return null;
    }

    /**
     * Retrieves total revenue (FR-06).
     * @return Total amount from all transactions
     */
    public Double getTotalRevenue() {
        String query = "SELECT SUM(amount) as total FROM transactions WHERE transaction_type IN ('CREDIT', 'PAYMENT')";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                return rs.getDouble("total");
            }
        } catch (SQLException e) {
            System.err.println("Error calculating total revenue: " + e.getMessage());
        }
        return 0.0;
    }

    /**
     * Retrieves transactions by type.
     * @param transaction_type Type of transaction
     * @return List of transactions
     */
    public List<Transaction> getTransactionsByType(String transaction_type) {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM transactions WHERE transaction_type = ? ORDER BY created_date DESC";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, transaction_type);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Transaction transaction = new Transaction.TransactionBuilder(
                        rs.getString("transaction_id"),
                        rs.getString("user_id"),
                        transaction_type,
                        rs.getDouble("amount")
                    )
                    .build();

                transactions.add(transaction);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving transactions by type: " + e.getMessage());
        }
        return transactions;
    }
}