package dao;

import model.Sponsor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Sponsor.
 * Handles database operations for sponsors.
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class SponsorDAO {
    private Connection connection;

    public SponsorDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Creates a new sponsor.
     * @param sponsor The Sponsor to create
     * @return True if successful
     */
    public boolean createSponsor(Sponsor sponsor) {
        String insertSQL = "INSERT INTO sponsors (user_id, company_name, sponsorship_amount, rating, scooters_donated) " +
                          "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
            ps.setString(1, sponsor.getUserId());
            ps.setString(2, sponsor.getCompanyName());
            ps.setDouble(3, sponsor.getSponsorshipAmount());
            ps.setInt(4, sponsor.getRating());
            ps.setInt(5, sponsor.getScootersDonated());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creating sponsor: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves sponsor by user ID.
     * @param user_id The user ID
     * @return Sponsor or null if not found
     */
    public Sponsor getSponsorById(String user_id) {
        String query = "SELECT * FROM sponsors WHERE user_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, user_id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Sponsor.SponsorBuilder(
                        rs.getString("user_id"),
                        rs.getString("company_name")
                    )
                    .sponsorshipAmount(rs.getDouble("sponsorship_amount"))
                    .rating(rs.getInt("rating"))
                    .scootersDonated(rs.getInt("scooters_donated"))
                    .build();
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving sponsor: " + e.getMessage());
        }
        return null;
    }

    /**
     * Retrieves all sponsors.
     * @return List of all sponsors
     */
    public List<Sponsor> getAllSponsors() {
        List<Sponsor> sponsors = new ArrayList<>();
        String query = "SELECT * FROM sponsors ORDER BY sponsorship_amount DESC";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Sponsor sponsor = new Sponsor.SponsorBuilder(
                        rs.getString("user_id"),
                        rs.getString("company_name")
                    )
                    .sponsorshipAmount(rs.getDouble("sponsorship_amount"))
                    .rating(rs.getInt("rating"))
                    .scootersDonated(rs.getInt("scooters_donated"))
                    .build();

                sponsors.add(sponsor);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving all sponsors: " + e.getMessage());
        }
        return sponsors;
    }

    /**
     * Updates sponsor rating.
     * @param user_id The sponsor user ID
     * @param rating New rating
     * @return True if successful
     */
    public boolean updateSponsorRating(String user_id, Integer rating) {
        String updateSQL = "UPDATE sponsors SET rating = ?, updated_date = CURRENT_TIMESTAMP WHERE user_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(updateSQL)) {
            ps.setInt(1, rating);
            ps.setString(2, user_id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating sponsor rating: " + e.getMessage());
            return false;
        }
    }

    /**
     * Gets total sponsorship amount.
     * @return Total sponsorship across all sponsors
     */
    public Double getTotalSponsorship() {
        String query = "SELECT SUM(sponsorship_amount) as total FROM sponsors";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                return rs.getDouble("total");
            }
        } catch (SQLException e) {
            System.err.println("Error calculating total sponsorship: " + e.getMessage());
        }
        return 0.0;
    }
}