package dao;

import model.UsageHistory;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for UsageHistory.
 * Handles database operations for scooter usage tracking.
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class UsageHistoryDAO {
    private Connection connection;

    public UsageHistoryDAO(Connection connection) {
        this.connection = connection;
    }

    /**
     * Creates a new usage history record.
     * @param usage The UsageHistory to create
     * @return True if successful
     */
    public boolean createUsageHistory(UsageHistory usage) {
        String insertSQL = "INSERT INTO usage_history (usage_id, scooter_id, user_id, start_station_id, end_station_id, " +
                          "locations, distance, start_time, end_time, cost) " +
                          "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(insertSQL)) {
            ps.setString(1, usage.getUsageId());
            ps.setString(2, usage.getScooterId());
            ps.setString(3, usage.getUserId());
            ps.setString(4, usage.getStartStationId());
            ps.setString(5, usage.getEndStationId());
            ps.setString(6, usage.getLocations());
            ps.setDouble(7, usage.getDistance());
            ps.setString(8, usage.getStartTime());
            ps.setString(9, usage.getEndTime());
            ps.setDouble(10, usage.getCost());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error creating usage history: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves usage history by user.
     * @param user_id The user ID
     * @return List of UsageHistory objects
     */
    public List<UsageHistory> getUsageHistoryByUser(String user_id) {
        List<UsageHistory> usage = new ArrayList<>();
        String query = "SELECT * FROM usage_history WHERE user_id = ? ORDER BY start_time DESC";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, user_id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                UsageHistory u = new UsageHistory.UsageHistoryBuilder(
                        rs.getString("usage_id"),
                        rs.getString("scooter_id"),
                        rs.getString("user_id")
                    )
                    .startStationId(rs.getString("start_station_id"))
                    .endStationId(rs.getString("end_station_id"))
                    .locations(rs.getString("locations"))
                    .distance(rs.getDouble("distance"))
                    .startTime(rs.getString("start_time"))
                    .endTime(rs.getString("end_time"))
                    .cost(rs.getDouble("cost"))
                    .build();

                usage.add(u);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving usage history: " + e.getMessage());
        }
        return usage;
    }

    /**
     * Retrieves usage history by scooter.
     * @param scooter_id The scooter ID
     * @return List of UsageHistory objects
     */
    public List<UsageHistory> getUsageHistoryByScooter(String scooter_id) {
        List<UsageHistory> usage = new ArrayList<>();
        String query = "SELECT * FROM usage_history WHERE scooter_id = ? ORDER BY start_time DESC";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, scooter_id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                UsageHistory u = new UsageHistory.UsageHistoryBuilder(
                        rs.getString("usage_id"),
                        scooter_id,
                        rs.getString("user_id")
                    )
                    .distance(rs.getDouble("distance"))
                    .cost(rs.getDouble("cost"))
                    .build();

                usage.add(u);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving usage history for scooter: " + e.getMessage());
        }
        return usage;
    }

    /**
     * Gets total distance traveled by scooter.
     * @param scooter_id The scooter ID
     * @return Total distance in km
     */
    public Double getTotalDistanceByScooter(String scooter_id) {
        String query = "SELECT SUM(distance) as total FROM usage_history WHERE scooter_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, scooter_id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getDouble("total");
            }
        } catch (SQLException e) {
            System.err.println("Error calculating total distance: " + e.getMessage());
        }
        return 0.0;
    }

    /**
     * Gets total usage cost for user.
     * @param user_id The user ID
     * @return Total cost
     */
    public Double getTotalCostByUser(String user_id) {
        String query = "SELECT SUM(cost) as total FROM usage_history WHERE user_id = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, user_id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getDouble("total");
            }
        } catch (SQLException e) {
            System.err.println("Error calculating total cost: " + e.getMessage());
        }
        return 0.0;
    }

    /**
     * Gets usage statistics for reporting (FR-06).
     * @return Total scooter usage count
     */
    public Integer getTotalUsageCount() {
        String query = "SELECT COUNT(*) as count FROM usage_history";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            System.err.println("Error counting total usage: " + e.getMessage());
        }
        return 0;
    }

    /**
     * Gets average trip distance.
     * @return Average distance in km
     */
    public Double getAverageTripDistance() {
        String query = "SELECT AVG(distance) as average FROM usage_history";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                return rs.getDouble("average");
            }
        } catch (SQLException e) {
            System.err.println("Error calculating average distance: " + e.getMessage());
        }
        return 0.0;
    }
}