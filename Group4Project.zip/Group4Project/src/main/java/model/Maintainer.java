package model;

/**
 * Maintainer user model.
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class Maintainer {
    private String user_id;
    private String specialization;
    private String certification;
    private String availability_status;
    private Integer tasks_completed;
    private String created_date;
    private String updated_date;

    private Maintainer(MaintainerBuilder builder) {
        this.user_id = builder.user_id;
        this.specialization = builder.specialization;
        this.certification = builder.certification;
        this.availability_status = builder.availability_status;
        this.tasks_completed = builder.tasks_completed;
        this.created_date = builder.created_date;
        this.updated_date = builder.updated_date;
    }

    /**
     * Builder for Maintainer.
     */
    public static class MaintainerBuilder {
        private String user_id;
        private String specialization;
        private String certification;
        private String availability_status = "AVAILABLE";
        private Integer tasks_completed = 0;
        private String created_date;
        private String updated_date;

        public MaintainerBuilder(String user_id) {
            this.user_id = user_id;
        }

        public MaintainerBuilder specialization(String specialization) {
            this.specialization = specialization;
            return this;
        }

        public MaintainerBuilder certification(String certification) {
            this.certification = certification;
            return this;
        }

        public MaintainerBuilder availabilityStatus(String availability_status) {
            if (!availability_status.matches("^(AVAILABLE|BUSY|UNAVAILABLE)$")) {
                throw new IllegalArgumentException("Invalid availability_status");
            }
            this.availability_status = availability_status;
            return this;
        }

        public MaintainerBuilder tasksCompleted(Integer tasks_completed) {
            this.tasks_completed = tasks_completed;
            return this;
        }

        public Maintainer build() {
            if (this.user_id == null || this.user_id.isEmpty()) {
                throw new IllegalArgumentException("user_id is required");
            }
            return new Maintainer(this);
        }
    }

    // Getters
    public String getUserId() { return user_id; }
    public String getSpecialization() { return specialization; }
    public String getCertification() { return certification; }
    public String getAvailabilityStatus() { return availability_status; }
    public Integer getTasksCompleted() { return tasks_completed; }
    public String getCreatedDate() { return created_date; }
    public String getUpdatedDate() { return updated_date; }
}