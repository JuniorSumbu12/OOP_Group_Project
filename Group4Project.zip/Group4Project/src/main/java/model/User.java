package model;

/**
 * Represents a user in the CESC system.
 * Users can have three types: USER, SPONSOR, or MAINTAINER.
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class User {
    private final String user_id;
    private final String name;
    private final String email;
    private final String password_hash;
    private final String user_type;
    private final Double credits;
    private final String created_date;
    private final String updated_date;
    private final Boolean is_active;

    /**
     * Private constructor - use UserBuilder for object creation.
     * @param builder The UserBuilder containing user data
     */
    private User(UserBuilder builder) {
        this.user_id = builder.user_id;
        this.name = builder.name;
        this.email = builder.email;
        this.password_hash = builder.password_hash;
        this.user_type = builder.user_type;
        this.credits = builder.credits;
        this.created_date = builder.created_date;
        this.updated_date = builder.updated_date;
        this.is_active = builder.is_active;
    }

    /**
     * Builder class for User with validation.
     */
    public static class UserBuilder {
        private String user_id;
        private String name;
        private String email;
        private String password_hash;
        private String user_type;
        private Double credits = 0.0;
        private String created_date;
        private String updated_date;
        private Boolean is_active = true;

        /**
         * Creates UserBuilder with required fields.
         * @param user_id Unique user identifier
         * @param email User email address
         */
        public UserBuilder(String user_id, String email) {
            this.user_id = user_id;
            this.email = email;
        }

        public UserBuilder name(String name) {
            this.name = name;
            return this;
        }

        public UserBuilder passwordHash(String password_hash) {
            this.password_hash = password_hash;
            return this;
        }

        public UserBuilder userType(String user_type) {
            if (!user_type.matches("^(USER|SPONSOR|MAINTAINER)$")) {
                throw new IllegalArgumentException("Invalid user_type. Must be USER, SPONSOR, or MAINTAINER");
            }
            this.user_type = user_type;
            return this;
        }

        public UserBuilder credits(Double credits) {
            if (credits < 0) {
                throw new IllegalArgumentException("Credits cannot be negative");
            }
            this.credits = credits;
            return this;
        }

        public UserBuilder createdDate(String created_date) {
            this.created_date = created_date;
            return this;
        }

        public UserBuilder updatedDate(String updated_date) {
            this.updated_date = updated_date;
            return this;
        }

        public UserBuilder isActive(Boolean is_active) {
            this.is_active = is_active;
            return this;
        }

        /**
         * Builds and returns User with validation.
         * @return New User instance
         * @throws IllegalArgumentException if validation fails
         */
        public User build() {
            if (this.user_id == null || this.user_id.isEmpty()) {
                throw new IllegalArgumentException("user_id is required");
            }
            if (this.email == null || this.email.isEmpty()) {
                throw new IllegalArgumentException("email is required");
            }
            if (this.password_hash == null || this.password_hash.isEmpty()) {
                throw new IllegalArgumentException("password_hash is required");
            }
            if (this.user_type == null || this.user_type.isEmpty()) {
                throw new IllegalArgumentException("user_type is required");
            }
            return new User(this);
        }
    }

    // Getters
    public String getUserId() { return user_id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPasswordHash() { return password_hash; }
    public String getUserType() { return user_type; }
    public Double getCredits() { return credits != null ? credits : 0.0; }
    public String getCreatedDate() { return created_date; }
    public String getUpdatedDate() { return updated_date; }
    public Boolean getIsActive() { return is_active != null ? is_active : true; }

    @Override
    public String toString() {
        return "User{" + "user_id='" + user_id + '\'' + ", name='" + name + '\'' +
               ", email='" + email + '\'' + ", user_type='" + user_type + '\'' +
               ", credits=" + credits + ", is_active=" + is_active + '}';
    }
}