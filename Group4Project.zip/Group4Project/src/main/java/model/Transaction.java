package model;

/**
 * Financial transaction (FR-06).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class Transaction {
    private final String transaction_id;
    private final String user_id;
    private final String scooter_id;
    private final String transaction_type;
    private final Double amount;
    private final String category;
    private final String description;
    private final String created_date;

    private Transaction(TransactionBuilder builder) {
        this.transaction_id = builder.transaction_id;
        this.user_id = builder.user_id;
        this.scooter_id = builder.scooter_id;
        this.transaction_type = builder.transaction_type;
        this.amount = builder.amount;
        this.category = builder.category;
        this.description = builder.description;
        this.created_date = builder.created_date;
    }

    /**
     * Builder for Transaction with validation.
     */
    public static class TransactionBuilder {
        private String transaction_id;
        private String user_id;
        private String scooter_id;
        private String transaction_type;
        private Double amount;
        private String category;
        private String description;
        private String created_date;

        /**
         * Creates builder with required fields.
         * @param transaction_id Unique ID
         * @param user_id User involved
         * @param transaction_type Type of transaction
         * @param amount Amount (must be positive)
         */
        public TransactionBuilder(String transaction_id, String user_id, String transaction_type, Double amount) {
            this.transaction_id = transaction_id;
            this.user_id = user_id;
            this.transaction_type = transaction_type;
            this.amount = amount;
        }

        public TransactionBuilder scooterId(String scooter_id) {
            this.scooter_id = scooter_id;
            return this;
        }

        public TransactionBuilder category(String category) {
            this.category = category;
            return this;
        }

        public TransactionBuilder description(String description) {
            this.description = description;
            return this;
        }

        public TransactionBuilder createdDate(String created_date) {
            this.created_date = created_date;
            return this;
        }

        public Transaction build() {
            if (this.transaction_id == null || this.transaction_id.isEmpty()) {
                throw new IllegalArgumentException("transaction_id is required");
            }
            if (this.user_id == null || this.user_id.isEmpty()) {
                throw new IllegalArgumentException("user_id is required");
            }
            if (this.amount == null || this.amount <= 0) {
                throw new IllegalArgumentException("amount must be positive");
            }
            if (!this.transaction_type.matches("^(DEBIT|CREDIT|REFUND|PENALTY|PAYMENT|MAINTENANCE_CREDIT|SPONSOR_CREDIT|ACCOUNT_TOPUP)$")) {
                throw new IllegalArgumentException("Invalid transaction_type");
            }
            return new Transaction(this);
        }
    }

    // Getters
    public String getTransactionId() { return transaction_id; }
    public String getUserId() { return user_id; }
    public String getScooterId() { return scooter_id; }
    public String getTransactionType() { return transaction_type; }
    public Double getAmount() { return amount != null ? amount : 0.0; }
    public String getCategory() { return category; }
    public String getDescription() { return description; }
    public String getCreatedDate() { return created_date; }

    @Override
    public String toString() {
        return "Transaction{" + "transaction_id='" + transaction_id + '\'' +
               ", user_id='" + user_id + '\'' +
               ", transaction_type='" + transaction_type + '\'' +
               ", amount=" + amount + '}';
    }
}