package model;

/**
 * Usage history for scooter rentals.
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class UsageHistory {
    private String usage_id;
    private String scooter_id;
    private String user_id;
    private String start_station_id;
    private String end_station_id;
    private String locations;
    private Double distance;
    private String start_time;
    private String end_time;
    private Double cost;

    private UsageHistory(UsageHistoryBuilder builder) {
        this.usage_id = builder.usage_id;
        this.scooter_id = builder.scooter_id;
        this.user_id = builder.user_id;
        this.start_station_id = builder.start_station_id;
        this.end_station_id = builder.end_station_id;
        this.locations = builder.locations;
        this.distance = builder.distance;
        this.start_time = builder.start_time;
        this.end_time = builder.end_time;
        this.cost = builder.cost;
    }

    /**
     * Builder for UsageHistory.
     */
    public static class UsageHistoryBuilder {
        private String usage_id;
        private String scooter_id;
        private String user_id;
        private String start_station_id;
        private String end_station_id;
        private String locations;
        private Double distance;
        private String start_time;
        private String end_time;
        private Double cost;

        public UsageHistoryBuilder(String usage_id, String scooter_id, String user_id) {
            this.usage_id = usage_id;
            this.scooter_id = scooter_id;
            this.user_id = user_id;
        }

        public UsageHistoryBuilder startStationId(String start_station_id) {
            this.start_station_id = start_station_id;
            return this;
        }

        public UsageHistoryBuilder endStationId(String end_station_id) {
            this.end_station_id = end_station_id;
            return this;
        }

        public UsageHistoryBuilder locations(String locations) {
            this.locations = locations;
            return this;
        }

        public UsageHistoryBuilder distance(Double distance) {
            if (distance < 0) {
                throw new IllegalArgumentException("distance cannot be negative");
            }
            this.distance = distance;
            return this;
        }

        public UsageHistoryBuilder startTime(String start_time) {
            this.start_time = start_time;
            return this;
        }

        public UsageHistoryBuilder endTime(String end_time) {
            this.end_time = end_time;
            return this;
        }

        public UsageHistoryBuilder cost(Double cost) {
            if (cost < 0) {
                throw new IllegalArgumentException("cost cannot be negative");
            }
            this.cost = cost;
            return this;
        }

        public UsageHistory build() {
            if (this.usage_id == null || this.usage_id.isEmpty()) {
                throw new IllegalArgumentException("usage_id is required");
            }
            if (this.scooter_id == null || this.scooter_id.isEmpty()) {
                throw new IllegalArgumentException("scooter_id is required");
            }
            if (this.user_id == null || this.user_id.isEmpty()) {
                throw new IllegalArgumentException("user_id is required");
            }
            return new UsageHistory(this);
        }
    }

    // Getters
    public String getUsageId() { return usage_id; }
    public String getScooterId() { return scooter_id; }
    public String getUserId() { return user_id; }
    public String getStartStationId() { return start_station_id; }
    public String getEndStationId() { return end_station_id; }
    public String getLocations() { return locations; }
    public Double getDistance() { return distance; }
    public String getStartTime() { return start_time; }
    public String getEndTime() { return end_time; }
    public Double getCost() { return cost; }
}