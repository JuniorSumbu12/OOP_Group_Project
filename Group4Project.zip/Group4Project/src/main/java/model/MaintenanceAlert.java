package model;

/**
 * Maintenance alert for predictive maintenance (FR-05).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class MaintenanceAlert {
    private final String alert_id;
    private final String scooter_id;
    private final String alert_type;
    private final String severity;
    private final String description;
    private final Boolean is_resolved;
    private final String created_date;
    private final String resolved_date;

    private MaintenanceAlert(MaintenanceAlertBuilder builder) {
        this.alert_id = builder.alert_id;
        this.scooter_id = builder.scooter_id;
        this.alert_type = builder.alert_type;
        this.severity = builder.severity;
        this.description = builder.description;
        this.is_resolved = builder.is_resolved;
        this.created_date = builder.created_date;
        this.resolved_date = builder.resolved_date;
    }

    /**
     * Builder for MaintenanceAlert with validation.
     */
    public static class MaintenanceAlertBuilder {
        private String alert_id;
        private String scooter_id;
        private String alert_type;
        private String severity;
        private String description;
        private Boolean is_resolved = false;
        private String created_date;
        private String resolved_date;

        /**
         * Creates builder with required fields.
         * @param alert_id Unique alert ID
         * @param scooter_id Scooter requiring maintenance
         */
        public MaintenanceAlertBuilder(String alert_id, String scooter_id) {
            this.alert_id = alert_id;
            this.scooter_id = scooter_id;
        }

        /**
         * Sets alert type (FR-05).
         * @param alert_type BATTERY, WHEELS, BRAKES, GENERAL_WEAR, LOW_CHARGE, HIGH_USAGE
         */
        public MaintenanceAlertBuilder alertType(String alert_type) {
            if (!alert_type.matches("^(BATTERY|WHEELS|BRAKES|GENERAL_WEAR|LOW_CHARGE|HIGH_USAGE)$")) {
                throw new IllegalArgumentException("Invalid alert_type");
            }
            this.alert_type = alert_type;
            return this;
        }

        /**
         * Sets severity level (FR-05).
         * @param severity LOW, MEDIUM, HIGH, or CRITICAL
         */
        public MaintenanceAlertBuilder severity(String severity) {
            if (!severity.matches("^(LOW|MEDIUM|HIGH|CRITICAL)$")) {
                throw new IllegalArgumentException("Severity must be LOW, MEDIUM, HIGH, or CRITICAL");
            }
            this.severity = severity;
            return this;
        }

        public MaintenanceAlertBuilder description(String description) {
            this.description = description;
            return this;
        }

        public MaintenanceAlertBuilder isResolved(Boolean is_resolved) {
            this.is_resolved = is_resolved;
            return this;
        }

        public MaintenanceAlertBuilder createdDate(String created_date) {
            this.created_date = created_date;
            return this;
        }

        public MaintenanceAlertBuilder resolvedDate(String resolved_date) {
            this.resolved_date = resolved_date;
            return this;
        }

        public MaintenanceAlert build() {
            if (this.alert_id == null || this.alert_id.isEmpty()) {
                throw new IllegalArgumentException("alert_id is required");
            }
            if (this.scooter_id == null || this.scooter_id.isEmpty()) {
                throw new IllegalArgumentException("scooter_id is required");
            }
            if (this.alert_type == null || this.alert_type.isEmpty()) {
                throw new IllegalArgumentException("alert_type is required");
            }
            if (this.severity == null || this.severity.isEmpty()) {
                throw new IllegalArgumentException("severity is required");
            }
            return new MaintenanceAlert(this);
        }
    }

    // Getters
    public String getAlertId() { return alert_id; }
    public String getScooterId() { return scooter_id; }
    public String getAlertType() { return alert_type; }
    public String getSeverity() { return severity; }
    public String getDescription() { return description; }
    public Boolean getIsResolved() { return is_resolved != null ? is_resolved : false; }
    public String getCreatedDate() { return created_date; }
    public String getResolvedDate() { return resolved_date; }

    @Override
    public String toString() {
        return "MaintenanceAlert{" + "alert_id='" + alert_id + '\'' +
               ", scooter_id='" + scooter_id + '\'' +
               ", severity='" + severity + '\'' +
               ", is_resolved=" + is_resolved + '}';
    }
}