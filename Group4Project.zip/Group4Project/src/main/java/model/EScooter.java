package model;

/**
 * Represents an electric scooter in the CESC system.
 * Covers FR-02, FR-03, FR-04, FR-05
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class EScooter {
    private final String scooter_id;
    private final String vehicle_number;
    private final String make;
    private final String model;
    private final String color;
    private final Double battery_capacity;
    private final Double current_battery;
    private final String status;
    private final Double latitude;
    private final Double longitude;
    private final Double hours_used;
    private final String last_charged_at;
    private final String wheel_condition;
    private final String brake_condition;
    private final Integer battery_health_percentage;
    private final String owner_id;
    private final String current_station_id;
    private final Integer time_away_from_station;

    private EScooter(EScooterBuilder builder) {
        this.scooter_id = builder.scooter_id;
        this.vehicle_number = builder.vehicle_number;
        this.make = builder.make;
        this.model = builder.model;
        this.color = builder.color;
        this.battery_capacity = builder.battery_capacity;
        this.current_battery = builder.current_battery;
        this.status = builder.status;
        this.latitude = builder.latitude;
        this.longitude = builder.longitude;
        this.hours_used = builder.hours_used;
        this.last_charged_at = builder.last_charged_at;
        this.wheel_condition = builder.wheel_condition;
        this.brake_condition = builder.brake_condition;
        this.battery_health_percentage = builder.battery_health_percentage;
        this.owner_id = builder.owner_id;
        this.current_station_id = builder.current_station_id;
        this.time_away_from_station = builder.time_away_from_station;
    }

    /**
     * Builder for EScooter with comprehensive validation.
     */
    public static class EScooterBuilder {
        private String scooter_id;
        private String vehicle_number;
        private String make;
        private String model;
        private String color;
        private Double battery_capacity;
        private Double current_battery;
        private String status;
        private Double latitude;
        private Double longitude;
        private Double hours_used = 0.0;
        private String last_charged_at;
        private String wheel_condition = "GOOD";
        private String brake_condition = "GOOD";
        private Integer battery_health_percentage = 100;
        private String owner_id;
        private String current_station_id;
        private Integer time_away_from_station = 0;

        /**
         * Creates builder with required fields.
         * @param scooter_id Unique scooter ID
         * @param vehicle_number Vehicle registration
         * @param make Manufacturer (e.g., Xiaomi)
         * @param model Model name (e.g., Mi 3)
         */
        public EScooterBuilder(String scooter_id, String vehicle_number, String make, String model) {
            this.scooter_id = scooter_id;
            this.vehicle_number = vehicle_number;
            this.make = make;
            this.model = model;
        }

        public EScooterBuilder color(String color) {
            this.color = color;
            return this;
        }

        /**
         * Sets battery capacity (FR-04).
         * @param battery_capacity Must be positive
         * @return 
         * @throws IllegalArgumentException if not positive
         */
        public EScooterBuilder batteryCapacity(Double battery_capacity) {
            if (battery_capacity <= 0) {
                throw new IllegalArgumentException("battery_capacity must be positive");
            }
            this.battery_capacity = battery_capacity;
            return this;
        }

        /**
         * Sets current battery (FR-04).
         * @param current_battery 0-100 percentage
         * @return 
         * @throws IllegalArgumentException if not in range
         */
        public EScooterBuilder currentBattery(Double current_battery) {
            if (current_battery < 0 || current_battery > 100) {
                throw new IllegalArgumentException("current_battery must be between 0 and 100");
            }
            this.current_battery = current_battery;
            return this;
        }

        /**
         * Sets scooter status (FR-02).
         * @param status AVAILABLE, IN_TRANSIT, CHARGING, MAINTENANCE, or INACTIVE
         * @return 
         */
        public EScooterBuilder status(String status) {
            if (!status.matches("^(AVAILABLE|IN_TRANSIT|CHARGING|MAINTENANCE|INACTIVE)$")) {
                throw new IllegalArgumentException("Invalid status");
            }
            this.status = status;
            return this;
        }

        /**
         * Sets GPS location (FR-03).
         * @param latitude -90 to 90
         * @param longitude -180 to 180
         * @return 
         */
        public EScooterBuilder location(Double latitude, Double longitude) {
            if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
                throw new IllegalArgumentException("Invalid coordinates");
            }
            this.latitude = latitude;
            this.longitude = longitude;
            return this;
        }

        public EScooterBuilder hoursUsed(Double hours_used) {
            if (hours_used < 0) {
                throw new IllegalArgumentException("hours_used cannot be negative");
            }
            this.hours_used = hours_used;
            return this;
        }

        public EScooterBuilder wheelCondition(String wheel_condition) {
            this.wheel_condition = wheel_condition;
            return this;
        }

        public EScooterBuilder brakeCondition(String brake_condition) {
            this.brake_condition = brake_condition;
            return this;
        }

        public EScooterBuilder batteryHealthPercentage(Integer battery_health_percentage) {
            if (battery_health_percentage < 0 || battery_health_percentage > 100) {
                throw new IllegalArgumentException("battery_health_percentage must be between 0 and 100");
            }
            this.battery_health_percentage = battery_health_percentage;
            return this;
        }

        public EScooterBuilder currentStationId(String current_station_id) {
            this.current_station_id = current_station_id;
            return this;
        }

        public EScooter build() {
            if (this.scooter_id == null || this.scooter_id.isEmpty()) {
                throw new IllegalArgumentException("scooter_id is required");
            }
            if (this.vehicle_number == null || this.vehicle_number.isEmpty()) {
                throw new IllegalArgumentException("vehicle_number is required");
            }
            if (this.make == null || this.make.isEmpty()) {
                throw new IllegalArgumentException("make is required");
            }
            if (this.model == null || this.model.isEmpty()) {
                throw new IllegalArgumentException("model is required");
            }
            if (this.battery_capacity == null || this.battery_capacity <= 0) {
                throw new IllegalArgumentException("battery_capacity is required and must be positive");
            }
            if (this.current_battery == null) {
                throw new IllegalArgumentException("current_battery is required");
            }
            if (this.status == null || this.status.isEmpty()) {
                throw new IllegalArgumentException("status is required");
            }
            return new EScooter(this);
        }
    }

    // Getters
    public String getScooterId() { return scooter_id; }
    public String getVehicleNumber() { return vehicle_number; }
    public String getMake() { return make; }
    public String getModel() { return model; }
    public String getColor() { return color; }
    public Double getBatteryCapacity() { return battery_capacity; }
    public Double getCurrentBattery() { return current_battery != null ? current_battery : 0.0; }
    public String getStatus() { return status; }
    public Double getLatitude() { return latitude; }
    public Double getLongitude() { return longitude; }
    public Double getHoursUsed() { return hours_used != null ? hours_used : 0.0; }
    public String getLastChargedAt() { return last_charged_at; }
    public String getWheelCondition() { return wheel_condition; }
    public String getBrakeCondition() { return brake_condition; }
    public Integer getBatteryHealthPercentage() { return battery_health_percentage != null ? battery_health_percentage : 100; }
    public String getOwnerId() { return owner_id; }
    public String getCurrentStationId() { return current_station_id; }
    public Integer getTimeAwayFromStation() { return time_away_from_station; }

    @Override
    public String toString() {
        return "EScooter{" + "scooter_id='" + scooter_id + '\'' +
               ", vehicle_number='" + vehicle_number + '\'' +
               ", status='" + status + '\'' +
               ", current_battery=" + current_battery + '}';
    }
}