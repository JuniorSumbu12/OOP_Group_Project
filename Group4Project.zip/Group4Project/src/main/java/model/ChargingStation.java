package model;

/**
 * Charging station for scooters.
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class ChargingStation {
    private String station_id;
    private String name;
    private String building;
    private Double latitude;
    private Double longitude;
    private Integer max_capacity;
    private Integer current_scooters;
    private Integer chargers;
    private String created_date;
    private String updated_date;

    private ChargingStation(ChargingStationBuilder builder) {
        this.station_id = builder.station_id;
        this.name = builder.name;
        this.building = builder.building;
        this.latitude = builder.latitude;
        this.longitude = builder.longitude;
        this.max_capacity = builder.max_capacity;
        this.current_scooters = builder.current_scooters;
        this.chargers = builder.chargers;
        this.created_date = builder.created_date;
        this.updated_date = builder.updated_date;
    }

    /**
     * Builder for ChargingStation.
     */
    public static class ChargingStationBuilder {
        private String station_id;
        private String name;
        private String building;
        private Double latitude;
        private Double longitude;
        private Integer max_capacity;
        private Integer current_scooters = 0;
        private Integer chargers = 5;
        private String created_date;
        private String updated_date;

        public ChargingStationBuilder(String station_id, String name, Double latitude, Double longitude) {
            this.station_id = station_id;
            this.name = name;
            this.latitude = latitude;
            this.longitude = longitude;
        }

        public ChargingStationBuilder building(String building) {
            this.building = building;
            return this;
        }

        public ChargingStationBuilder maxCapacity(Integer max_capacity) {
            if (max_capacity <= 0) {
                throw new IllegalArgumentException("max_capacity must be positive");
            }
            this.max_capacity = max_capacity;
            return this;
        }

        public ChargingStationBuilder chargers(Integer chargers) {
            this.chargers = chargers;
            return this;
        }

        public ChargingStation build() {
            if (this.station_id == null || this.station_id.isEmpty()) {
                throw new IllegalArgumentException("station_id is required");
            }
            if (this.name == null || this.name.isEmpty()) {
                throw new IllegalArgumentException("name is required");
            }
            if (this.max_capacity == null) {
                throw new IllegalArgumentException("max_capacity is required");
            }
            return new ChargingStation(this);
        }
    }

    // Getters
    public String getStationId() { return station_id; }
    public String getName() { return name; }
    public String getBuilding() { return building; }
    public Double getLatitude() { return latitude; }
    public Double getLongitude() { return longitude; }
    public Integer getMaxCapacity() { return max_capacity; }
    public Integer getCurrentScooters() { return current_scooters; }
    public Integer getChargers() { return chargers; }
    public String getCreatedDate() { return created_date; }
    public String getUpdatedDate() { return updated_date; }
}