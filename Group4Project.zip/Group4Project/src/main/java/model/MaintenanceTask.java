package model;

/**
 * Maintenance task assigned to maintainers.
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class MaintenanceTask {
    private String task_id;
    private String scooter_id;
    private String maintainer_id;
    private String task_type;
    private String status;
    private String issue_description;
    private String created_date;
    private String completed_date;

    private MaintenanceTask(MaintenanceTaskBuilder builder) {
        this.task_id = builder.task_id;
        this.scooter_id = builder.scooter_id;
        this.maintainer_id = builder.maintainer_id;
        this.task_type = builder.task_type;
        this.status = builder.status;
        this.issue_description = builder.issue_description;
        this.created_date = builder.created_date;
        this.completed_date = builder.completed_date;
    }

    /**
     * Builder for MaintenanceTask.
     */
    public static class MaintenanceTaskBuilder {
        private String task_id;
        private String scooter_id;
        private String maintainer_id;
        private String task_type;
        private String status = "PENDING";
        private String issue_description;
        private String created_date;
        private String completed_date;

        public MaintenanceTaskBuilder(String task_id, String scooter_id) {
            this.task_id = task_id;
            this.scooter_id = scooter_id;
        }

        public MaintenanceTaskBuilder maintainerId(String maintainer_id) {
            this.maintainer_id = maintainer_id;
            return this;
        }

        public MaintenanceTaskBuilder taskType(String task_type) {
            if (!task_type.matches("^(INSPECTION|REPAIR|REPLACEMENT|CLEANING|CHARGING)$")) {
                throw new IllegalArgumentException("Invalid task_type");
            }
            this.task_type = task_type;
            return this;
        }

        public MaintenanceTaskBuilder status(String status) {
            if (!status.matches("^(PENDING|IN_PROGRESS|COMPLETED|CANCELLED)$")) {
                throw new IllegalArgumentException("Invalid status");
            }
            this.status = status;
            return this;
        }

        public MaintenanceTaskBuilder issueDescription(String issue_description) {
            this.issue_description = issue_description;
            return this;
        }

        public MaintenanceTask build() {
            if (this.task_id == null || this.task_id.isEmpty()) {
                throw new IllegalArgumentException("task_id is required");
            }
            if (this.scooter_id == null || this.scooter_id.isEmpty()) {
                throw new IllegalArgumentException("scooter_id is required");
            }
            return new MaintenanceTask(this);
        }
    }

    // Getters
    public String getTaskId() { return task_id; }
    public String getScooterId() { return scooter_id; }
    public String getMaintainerId() { return maintainer_id; }
    public String getTaskType() { return task_type; }
    public String getStatus() { return status; }
    public String getIssueDescription() { return issue_description; }
    public String getCreatedDate() { return created_date; }
    public String getCompletedDate() { return completed_date; }
}