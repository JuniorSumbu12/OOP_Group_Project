package model;

/**
 * Sponsor user model.
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
public class Sponsor {
    private final String user_id;
    private final String company_name;
    private final Double sponsorship_amount;
    private final Integer rating;
    private final Integer scooters_donated;
    private final String created_date;
    private final String updated_date;

    private Sponsor(SponsorBuilder builder) {
        this.user_id = builder.user_id;
        this.company_name = builder.company_name;
        this.sponsorship_amount = builder.sponsorship_amount;
        this.rating = builder.rating;
        this.scooters_donated = builder.scooters_donated;
        this.created_date = builder.created_date;
        this.updated_date = builder.updated_date;
    }

    /**
     * Builder for Sponsor.
     */
    public static class SponsorBuilder {
        private String user_id;
        private String company_name;
        private Double sponsorship_amount = 0.0;
        private Integer rating = 0;
        private Integer scooters_donated = 0;
        private String created_date;
        private String updated_date;

        public SponsorBuilder(String user_id, String company_name) {
            this.user_id = user_id;
            this.company_name = company_name;
        }

        public SponsorBuilder sponsorshipAmount(Double sponsorship_amount) {
            if (sponsorship_amount < 0) {
                throw new IllegalArgumentException("sponsorship_amount cannot be negative");
            }
            this.sponsorship_amount = sponsorship_amount;
            return this;
        }

        public SponsorBuilder rating(Integer rating) {
            if (rating < 0 || rating > 5) {
                throw new IllegalArgumentException("rating must be between 0 and 5");
            }
            this.rating = rating;
            return this;
        }

        public SponsorBuilder scootersDonated(Integer scooters_donated) {
            this.scooters_donated = scooters_donated;
            return this;
        }

        public Sponsor build() {
            if (this.user_id == null || this.user_id.isEmpty()) {
                throw new IllegalArgumentException("user_id is required");
            }
            if (this.company_name == null || this.company_name.isEmpty()) {
                throw new IllegalArgumentException("company_name is required");
            }
            return new Sponsor(this);
        }
    }

    // Getters
    public String getUserId() { return user_id; }
    public String getCompanyName() { return company_name; }
    public Double getSponsorshipAmount() { return sponsorship_amount; }
    public Integer getRating() { return rating; }
    public Integer getScootersDonated() { return scooters_donated; }
    public String getCreatedDate() { return created_date; }
    public String getUpdatedDate() { return updated_date; }
}