-- ============================================================
-- CESC DATABASE SETUP SCRIPT (Final Production Version)
-- Campus E-Scooter Sharing CoOp - CST8288
-- ============================================================

CREATE USER IF NOT EXISTS 'cst8288'@'localhost' IDENTIFIED BY 'cst8288';
GRANT ALL PRIVILEGES ON cesc_db.* TO 'cst8288'@'localhost';
FLUSH PRIVILEGES;

DROP DATABASE IF EXISTS cesc_db;
CREATE DATABASE IF NOT EXISTS cesc_db;
USE cesc_db;

-- ============================================================
-- TABLE: users
-- FR-01: User Registration & Authentication
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    user_id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    user_type VARCHAR(20) NOT NULL CHECK (user_type IN ('USER', 'SPONSOR', 'MAINTAINER')),
    credits DOUBLE NOT NULL DEFAULT 0.0,
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    
    KEY idx_email (email),
    KEY idx_user_type (user_type),
    KEY idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: sponsors
-- FR-01: Sponsor Registration & Credit System
-- ============================================================
CREATE TABLE IF NOT EXISTS sponsors (
    user_id VARCHAR(36) PRIMARY KEY,
    company_name VARCHAR(255),
    sponsorship_amount DOUBLE NOT NULL DEFAULT 0.0,
    rating DOUBLE NOT NULL DEFAULT 0.0,
    scooters_donated INT NOT NULL DEFAULT 0,
    contact_person VARCHAR(100),
    phone VARCHAR(20),
    address VARCHAR(500),
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: maintainers
-- FR-01: Maintainer Registration & Certification
-- ============================================================
CREATE TABLE IF NOT EXISTS maintainers (
    user_id VARCHAR(36) PRIMARY KEY,
    specialization VARCHAR(255),
    certification_level VARCHAR(100),
    rating DOUBLE NOT NULL DEFAULT 0.0,
    tasks_completed INT NOT NULL DEFAULT 0,
    scooters_maintained INT NOT NULL DEFAULT 0,
    hours_available_per_week INT NOT NULL DEFAULT 40,
    phone VARCHAR(20),
    availability_status VARCHAR(20) DEFAULT 'AVAILABLE' CHECK (availability_status IN ('AVAILABLE', 'BUSY', 'ON_LEAVE')),
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: charging_stations
-- FR-01, FR-03: Station Management & GPS Tracking
-- ============================================================
CREATE TABLE IF NOT EXISTS charging_stations (
    station_id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    building VARCHAR(100),
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    max_capacity INT NOT NULL,
    chargers INT NOT NULL DEFAULT 5,
    current_scooters INT NOT NULL DEFAULT 0,
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    KEY idx_name (name),
    KEY idx_building (building)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: e_scooters
-- FR-02: E-Scooter Management, FR-03: GPS Tracking, 
-- FR-04: Energy Monitoring, FR-05: Maintenance Alerts
-- ============================================================
CREATE TABLE IF NOT EXISTS e_scooters (
    scooter_id VARCHAR(36) PRIMARY KEY,
    vehicle_number VARCHAR(50) UNIQUE NOT NULL,
    make VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    color VARCHAR(50),
    battery_capacity DOUBLE NOT NULL,
    current_battery DOUBLE NOT NULL,
    status VARCHAR(20) NOT NULL CHECK (status IN ('AVAILABLE', 'IN_TRANSIT', 'CHARGING', 'MAINTENANCE', 'INACTIVE')),
    latitude DOUBLE,
    longitude DOUBLE,
    hours_used DOUBLE NOT NULL DEFAULT 0.0,
    last_charged_at TIMESTAMP,
    wheel_condition VARCHAR(50) DEFAULT 'GOOD',
    brake_condition VARCHAR(50) DEFAULT 'GOOD',
    battery_health_percentage INT DEFAULT 100,
    owner_id VARCHAR(36),
    current_station_id VARCHAR(36),
    time_away_from_station INT DEFAULT 0,
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    KEY idx_vehicle_number (vehicle_number),
    KEY idx_status (status),
    KEY idx_owner_id (owner_id),
    KEY idx_station_id (current_station_id),
    
    FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (current_station_id) REFERENCES charging_stations(station_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: scooter_usage_history
-- FR-03: GPS Tracking, FR-04: Energy Monitoring, FR-06: Reporting
-- ============================================================
CREATE TABLE IF NOT EXISTS scooter_usage_history (
    usage_id VARCHAR(36) PRIMARY KEY,
    scooter_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    start_station_id VARCHAR(36),
    end_station_id VARCHAR(36),
    start_location_lat DOUBLE,
    start_location_lng DOUBLE,
    end_location_lat DOUBLE,
    end_location_lng DOUBLE,
    distance_traveled DOUBLE,
    duration_minutes INT,
    battery_used DOUBLE,
    cost_incurred DOUBLE,
    checkout_time TIMESTAMP,
    return_time TIMESTAMP,
    usage_status VARCHAR(20) DEFAULT 'COMPLETED' CHECK (usage_status IN ('COMPLETED', 'ONGOING', 'CANCELLED')),
    
    KEY idx_scooter_id (scooter_id),
    KEY idx_user_id (user_id),
    KEY idx_checkout_time (checkout_time),
    
    FOREIGN KEY (scooter_id) REFERENCES e_scooters(scooter_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: maintenance_tasks
-- FR-05: Alerts & Preventive Maintenance
-- ============================================================
CREATE TABLE IF NOT EXISTS maintenance_tasks (
    task_id VARCHAR(36) PRIMARY KEY,
    scooter_id VARCHAR(36) NOT NULL,
    maintainer_id VARCHAR(36),
    task_type VARCHAR(50) NOT NULL CHECK (task_type IN ('PREVENTIVE', 'CORRECTIVE', 'INSPECTION')),
    status VARCHAR(20) NOT NULL CHECK (status IN ('PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'SCHEDULED')),
    issue_description TEXT,
    parts_replaced VARCHAR(500),
    hours_worked DOUBLE DEFAULT 0.0,
    cost DOUBLE DEFAULT 0.0,
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_date TIMESTAMP NULL,
    
    KEY idx_scooter_id (scooter_id),
    KEY idx_maintainer_id (maintainer_id),
    KEY idx_status (status),
    KEY idx_task_type (task_type),
    
    FOREIGN KEY (scooter_id) REFERENCES e_scooters(scooter_id) ON DELETE CASCADE,
    FOREIGN KEY (maintainer_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: maintenance_alerts
-- FR-05: Alerts & Preventive Maintenance
-- ============================================================
CREATE TABLE IF NOT EXISTS maintenance_alerts (
    alert_id VARCHAR(36) PRIMARY KEY,
    scooter_id VARCHAR(36) NOT NULL,
    alert_type VARCHAR(50) CHECK (alert_type IN ('BATTERY', 'WHEELS', 'BRAKES', 'GENERAL_WEAR', 'LOW_CHARGE', 'HIGH_USAGE')),
    severity VARCHAR(20) CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
    description VARCHAR(500),
    is_resolved BOOLEAN DEFAULT FALSE,
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_date TIMESTAMP NULL,
    
    KEY idx_scooter_id (scooter_id),
    KEY idx_severity (severity),
    
    FOREIGN KEY (scooter_id) REFERENCES e_scooters(scooter_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: transactions
-- FR-06: Reporting & Analytics (Debit/Credit System)
-- ============================================================
CREATE TABLE IF NOT EXISTS transactions (
    transaction_id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    scooter_id VARCHAR(36),
    transaction_type VARCHAR(20) NOT NULL CHECK (transaction_type IN ('DEBIT', 'CREDIT', 'REFUND', 'PENALTY', 'PAYMENT', 'MAINTENANCE_CREDIT', 'SPONSOR_CREDIT', 'ACCOUNT_TOPUP')),
    amount DOUBLE NOT NULL,
    category VARCHAR(50),
    description TEXT,
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    KEY idx_user_id (user_id),
    KEY idx_scooter_id (scooter_id),
    KEY idx_transaction_type (transaction_type),
    KEY idx_created_date (created_date),
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (scooter_id) REFERENCES e_scooters(scooter_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: monthly_statements
-- FR-06: Reporting & Analytics (Monthly Billing)
-- ============================================================
CREATE TABLE IF NOT EXISTS monthly_statements (
    statement_id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    statement_month INT NOT NULL,
    statement_year INT NOT NULL,
    total_debits DOUBLE NOT NULL DEFAULT 0.0,
    total_credits DOUBLE NOT NULL DEFAULT 0.0,
    balance DOUBLE NOT NULL DEFAULT 0.0,
    due_date TIMESTAMP,
    paid_date TIMESTAMP NULL,
    payment_status VARCHAR(20) DEFAULT 'PENDING' CHECK (payment_status IN ('PENDING', 'OVERDUE', 'PAID')),
    created_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    KEY idx_user_id (user_id),
    KEY idx_month_year (statement_year, statement_month),
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: energy_usage_logs
-- FR-04: Energy Consumption Monitoring
-- ============================================================
CREATE TABLE IF NOT EXISTS energy_usage_logs (
    log_id VARCHAR(36) PRIMARY KEY,
    scooter_id VARCHAR(36) NOT NULL,
    battery_level_percent INT NOT NULL,
    estimated_charge_time_minutes INT,
    charging_station_id VARCHAR(36),
    log_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    KEY idx_scooter_id (scooter_id),
    KEY idx_timestamp (log_timestamp),
    
    FOREIGN KEY (scooter_id) REFERENCES e_scooters(scooter_id) ON DELETE CASCADE,
    FOREIGN KEY (charging_station_id) REFERENCES charging_stations(station_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: misplacement_reports
-- FR-01, FR-06: Maintainer recovery credits
-- ============================================================
CREATE TABLE IF NOT EXISTS misplacement_reports (
    report_id VARCHAR(36) PRIMARY KEY,
    scooter_id VARCHAR(36) NOT NULL,
    maintainer_id VARCHAR(36),
    reported_location_lat DOUBLE,
    reported_location_lng DOUBLE,
    condition_reported VARCHAR(500),
    action_taken VARCHAR(500),
    credits_earned DOUBLE NOT NULL DEFAULT 0.0,
    report_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_date TIMESTAMP NULL,
    
    KEY idx_maintainer_id (maintainer_id),
    KEY idx_scooter_id (scooter_id),
    
    FOREIGN KEY (scooter_id) REFERENCES e_scooters(scooter_id) ON DELETE CASCADE,
    FOREIGN KEY (maintainer_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: system_configuration
-- System settings for cost calculations
-- ============================================================
CREATE TABLE IF NOT EXISTS system_configuration (
    config_key VARCHAR(100) PRIMARY KEY,
    config_value VARCHAR(255) NOT NULL,
    description TEXT,
    updated_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SAMPLE DATA INSERTION
-- ============================================================

-- System configuration
INSERT INTO system_configuration (config_key, config_value, description) VALUES
('DEBIT_PER_MINUTE', '0.25', 'Cost per minute of usage'),
('DEBIT_PER_KM', '1.50', 'Cost per kilometer traveled'),
('LOW_BATTERY_THRESHOLD', '20', 'Battery percentage to trigger low battery alert'),
('HIGH_USAGE_THRESHOLD', '500', 'Hours used threshold for maintenance alert'),
('WHEEL_WEAR_THRESHOLD', '80', 'Wheel wear percentage threshold'),
('BRAKE_WEAR_THRESHOLD', '75', 'Brake wear percentage threshold'),
('CREDIT_PER_SCOOTER_RECOVERED', '5.00', 'Credit earned per misplaced scooter recovered');

-- Users
INSERT INTO users (user_id, name, email, password_hash, user_type, credits, is_active) VALUES
('user-001', 'John Smith', 'john@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36jbMG9m', 'USER', 150.00, TRUE),
('user-002', 'Sarah Johnson', 'sarah@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36jbMG9m', 'USER', 75.50, TRUE),
('user-003', 'Mike Chen', 'mike@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36jbMG9m', 'USER', 200.00, TRUE),
('sponsor-001', 'Tech Company Inc', 'sponsor@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36jbMG9m', 'SPONSOR', 500.00, TRUE),
('maintainer-001', 'Alex Rodriguez', 'alex@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcg7b3XeKeUxWdeS86E36jbMG9m', 'MAINTAINER', 300.00, TRUE);

-- Sponsors
INSERT INTO sponsors (user_id, company_name, sponsorship_amount, scooters_donated, contact_person, phone, address) VALUES
('sponsor-001', 'Tech Company Inc', 5000.00, 10, 'John Alexander', '613-555-0101', '123 Tech Street, Ottawa, ON');

-- Maintainers
INSERT INTO maintainers (user_id, specialization, certification_level, tasks_completed, scooters_maintained, phone, availability_status) VALUES
('maintainer-001', 'Battery & Electrical Systems', 'CERTIFIED_TECHNICIAN', 15, 45, '613-555-0201', 'AVAILABLE');

-- Charging Stations
INSERT INTO charging_stations (station_id, name, building, latitude, longitude, max_capacity, chargers, current_scooters) VALUES
('STATION-001', 'North Campus Station', 'North Entrance', 45.4275, -75.6445, 10, 5, 7),
('STATION-002', 'South Campus Station', 'South Entrance', 45.4260, -75.6445, 10, 5, 8),
('STATION-003', 'East Campus Station', 'East Parking', 45.4269, -75.6430, 8, 4, 5),
('STATION-004', 'Library Station', 'Main Library', 45.4270, -75.6450, 12, 6, 10),
('STATION-005', 'Cafeteria Station', 'Dining Hall', 45.4268, -75.6442, 6, 3, 4);

-- E-Scooters
INSERT INTO e_scooters (scooter_id, vehicle_number, make, model, color, battery_capacity, current_battery, status, latitude, longitude, hours_used, last_charged_at, current_station_id, wheel_condition, brake_condition, battery_health_percentage) VALUES
('scooter-001', 'SC-2025-001', 'Xiaomi', 'Mi 3', 'Black', 36.0, 28.5, 'AVAILABLE', 45.42690, -75.64470, 12.5, NOW(), 'STATION-001', 'GOOD', 'GOOD', 95),
('scooter-002', 'SC-2025-002', 'Xiaomi', 'Mi 3', 'White', 36.0, 15.2, 'CHARGING', 45.42700, -75.64480, 8.3, DATE_SUB(NOW(), INTERVAL 2 HOUR), 'STATION-002', 'FAIR', 'GOOD', 88),
('scooter-003', 'SC-2025-003', 'Ninebot', 'Max', 'Black', 40.0, 32.0, 'AVAILABLE', 45.42680, -75.64460, 5.1, NOW(), 'STATION-003', 'GOOD', 'GOOD', 92),
('scooter-004', 'SC-2025-004', 'Ninebot', 'Max', 'Red', 40.0, 8.5, 'CHARGING', 45.42710, -75.64490, 18.7, DATE_SUB(NOW(), INTERVAL 1 HOUR), 'STATION-004', 'WORN', 'FAIR', 75),
('scooter-005', 'SC-2025-005', 'Xiaomi', 'Mi 3', 'Blue', 36.0, 36.0, 'AVAILABLE', 45.42695, -75.64465, 550.0, NOW(), 'STATION-005', 'WORN', 'GOOD', 85);

-- Transactions
INSERT INTO transactions (transaction_id, user_id, scooter_id, transaction_type, amount, category, description) VALUES
('txn-001', 'user-001', 'scooter-001', 'DEBIT', 5.50, 'RENTAL', 'Scooter rental - 30 minutes'),
('txn-002', 'user-001', NULL, 'CREDIT', 25.00, 'ACCOUNT_TOPUP', 'Account top-up via card'),
('txn-003', 'user-002', 'scooter-003', 'DEBIT', 4.25, 'RENTAL', 'Scooter rental - 25 minutes'),
('txn-004', 'sponsor-001', NULL, 'CREDIT', 500.00, 'SPONSOR_CREDIT', 'Sponsor donation'),
('txn-005', 'maintainer-001', NULL, 'CREDIT', 100.00, 'MAINTENANCE_CREDIT', 'Maintenance work completed');

-- Maintenance Alerts
INSERT INTO maintenance_alerts (alert_id, scooter_id, alert_type, severity, description, is_resolved) VALUES
('alert-001', 'scooter-004', 'LOW_CHARGE', 'HIGH', 'Battery critically low at 21%', FALSE),
('alert-002', 'scooter-005', 'HIGH_USAGE', 'MEDIUM', 'High usage hours (550+). Maintenance recommended', FALSE),
('alert-003', 'scooter-005', 'WHEELS', 'MEDIUM', 'Wheel wear detected above 80%', FALSE),
('alert-004', 'scooter-002', 'BATTERY', 'MEDIUM', 'Battery health declining - 88%', FALSE);

-- Maintenance Tasks
INSERT INTO maintenance_tasks (task_id, scooter_id, maintainer_id, task_type, status, issue_description, parts_replaced, hours_worked, cost) VALUES
('MAINT-001', 'scooter-004', 'maintainer-001', 'CORRECTIVE', 'SCHEDULED', 'Low battery - needs charging cycle', NULL, 0.0, 0.0),
('MAINT-002', 'scooter-005', 'maintainer-001', 'PREVENTIVE', 'SCHEDULED', 'High usage maintenance - wheel and brake inspection', NULL, 0.0, 0.0);

-- Energy Usage Logs
INSERT INTO energy_usage_logs (log_id, scooter_id, battery_level_percent, estimated_charge_time_minutes, charging_station_id) VALUES
('log-001', 'scooter-001', 79, 120, 'STATION-001'),
('log-002', 'scooter-002', 42, 240, 'STATION-002'),
('log-003', 'scooter-003', 80, 115, 'STATION-003'),
('log-004', 'scooter-004', 21, 290, 'STATION-004'),
('log-005', 'scooter-005', 100, 0, 'STATION-005');

-- ============================================================
-- VERIFY INSTALLATION
-- ============================================================
SELECT '✅ CESC Database Setup Complete!' AS status;
SHOW TABLES;
