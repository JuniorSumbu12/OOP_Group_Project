package servlet;

import dao.EScooterDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;

/**
 * Servlet for updating scooter GPS location (FR-03).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
@WebServlet("/update-location")
public class UpdateScooterLocationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            String scooter_id = request.getParameter("scooter_id");
            String latitude = request.getParameter("latitude");
            String longitude = request.getParameter("longitude");

            if (scooter_id == null || latitude == null || longitude == null) {
                request.setAttribute("error", "Missing required parameters");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            try {
                Double lat = Double.parseDouble(latitude);
                Double lng = Double.parseDouble(longitude);

                if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
                    throw new IllegalArgumentException("Invalid coordinates");
                }

                Connection connection = (Connection) getServletContext().getAttribute("connection");
                if (connection == null) {
                    request.setAttribute("error", "Database connection failed");
                    request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                    return;
                }

                EScooterDAO scooterDAO = new EScooterDAO(connection);
                boolean updated = scooterDAO.updateScooterLocation(scooter_id, lat, lng);

                if (updated) {
                    request.setAttribute("success", "Scooter location updated successfully");
                } else {
                    request.setAttribute("error", "Failed to update location");
                }

                request.getRequestDispatcher("/jsp/scooters.jsp").forward(request, response);

            } catch (NumberFormatException e) {
                request.setAttribute("error", "Invalid latitude or longitude format");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
            } catch (IllegalArgumentException e) {
                request.setAttribute("error", "Invalid coordinates: " + e.getMessage());
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
            }

        } catch (Exception e) {
            System.err.println("Error updating location: " + e.getMessage());
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }
}