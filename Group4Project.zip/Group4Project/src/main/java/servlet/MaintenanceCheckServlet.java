package servlet;

import dao.EScooterDAO;
import dao.MaintenanceAlertDAO;
import model.EScooter;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;
import java.util.List;

/**
 * Servlet for checking scooters and generating maintenance alerts (FR-05).
 * 
 * Automatic threshold checks:
 * - Battery < 20% → LOW_CHARGE alert (HIGH severity)
 * - Usage > 500 hours → HIGH_USAGE alert (MEDIUM severity)
 * - Wheel condition = WORN → WHEELS alert (MEDIUM severity)
 * - Brake condition = WORN → BRAKES alert (HIGH severity)
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
@WebServlet("/maintenance-check")
public class MaintenanceCheckServlet extends HttpServlet {
    
    // FR-05: Maintenance Check Thresholds
    private static final int LOW_BATTERY_THRESHOLD = 20;
    private static final int HIGH_USAGE_THRESHOLD = 500;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            Connection connection = (Connection) getServletContext().getAttribute("connection");
            if (connection == null) {
                request.setAttribute("error", "Database connection failed");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            EScooterDAO scooterDAO = new EScooterDAO(connection);
            MaintenanceAlertDAO alertDAO = new MaintenanceAlertDAO(connection);

            List<EScooter> scooters = scooterDAO.getAllScooters();
            int alertsCreated = 0;

            // Check each scooter against thresholds (FR-05)
            for (EScooter scooter : scooters) {
                try {
                    // Check low battery (FR-04 + FR-05)
                    if (scooter.getCurrentBattery() < LOW_BATTERY_THRESHOLD) {
                        boolean created = alertDAO.createAlertWithBuilder(
                            scooter.getScooterId(),
                            "LOW_CHARGE",
                            "HIGH",
                            "Battery critically low at " + scooter.getCurrentBattery() + "%"
                        );
                        if (created) alertsCreated++;
                    }

                    // Check high usage hours (FR-05)
                    if (scooter.getHoursUsed() > HIGH_USAGE_THRESHOLD) {
                        boolean created = alertDAO.createAlertWithBuilder(
                            scooter.getScooterId(),
                            "HIGH_USAGE",
                            "MEDIUM",
                            "High usage hours (" + scooter.getHoursUsed() + "). Maintenance recommended"
                        );
                        if (created) alertsCreated++;
                    }

                    // Check wheel wear (FR-05)
                    if ("WORN".equals(scooter.getWheelCondition())) {
                        boolean created = alertDAO.createAlertWithBuilder(
                            scooter.getScooterId(),
                            "WHEELS",
                            "MEDIUM",
                            "Wheel wear detected. Replacement recommended"
                        );
                        if (created) alertsCreated++;
                    }

                    // Check brake wear (FR-05)
                    if ("WORN".equals(scooter.getBrakeCondition())) {
                        boolean created = alertDAO.createAlertWithBuilder(
                            scooter.getScooterId(),
                            "BRAKES",
                            "HIGH",
                            "Brake wear detected. Immediate inspection required"
                        );
                        if (created) alertsCreated++;
                    }
                } catch (IllegalArgumentException e) {
                    System.err.println("Invalid alert data for scooter " + scooter.getScooterId() + ": " + e.getMessage());
                }
            }

            request.setAttribute("alertsCreated", alertsCreated);
            request.setAttribute("alerts", alertDAO.getUnresolvedAlerts());
            request.getRequestDispatcher("/jsp/alerts.jsp").forward(request, response);

        } catch (Exception e) {
            System.err.println("Error in maintenance check: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Error running maintenance check: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }
}