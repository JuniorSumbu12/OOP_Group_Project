package servlet;

import dao.UserDAO;
import model.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;
import java.util.UUID;

/**
 * Servlet for user registration (FR-01).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String user_type = request.getParameter("user_type");

            if (name == null || email == null || password == null) {
                request.setAttribute("error", "All fields are required");
                request.getRequestDispatcher("/jsp/register.jsp").forward(request, response);
                return;
            }

            Connection connection = (Connection) getServletContext().getAttribute("connection");
            if (connection == null) {
                request.setAttribute("error", "Database connection failed");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            try {
                User user = new User.UserBuilder(UUID.randomUUID().toString(), email)
                    .name(name)
                    .passwordHash(password)
                    .userType(user_type != null ? user_type : "USER")
                    .build();

                UserDAO userDAO = new UserDAO(connection);
                boolean registered = userDAO.createUser(user);

                if (registered) {
                    request.setAttribute("success", "Registration successful! Please login.");
                    request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
                } else {
                    request.setAttribute("error", "Registration failed");
                    request.getRequestDispatcher("/jsp/register.jsp").forward(request, response);
                }
            } catch (IllegalArgumentException e) {
                request.setAttribute("error", "Invalid data: " + e.getMessage());
                request.getRequestDispatcher("/jsp/register.jsp").forward(request, response);
            }

        } catch (Exception e) {
            System.err.println("Error in registration: " + e.getMessage());
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/jsp/register.jsp").forward(request, response);
    }
}