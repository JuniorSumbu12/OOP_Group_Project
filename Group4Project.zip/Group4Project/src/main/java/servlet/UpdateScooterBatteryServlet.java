package servlet;

import dao.EScooterDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;

/**
 * Servlet for updating scooter battery level (FR-04).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
@WebServlet("/update-battery")
public class UpdateScooterBatteryServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            String scooter_id = request.getParameter("scooter_id");
            String battery = request.getParameter("battery");
            String health = request.getParameter("battery_health");

            if (scooter_id == null || battery == null) {
                request.setAttribute("error", "Missing required parameters");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            try {
                Double batteryLevel = Double.parseDouble(battery);
                Integer batteryHealth = (health != null) ? Integer.parseInt(health) : 100;

                if (batteryLevel < 0 || batteryLevel > 100) {
                    throw new IllegalArgumentException("Battery must be between 0 and 100");
                }
                if (batteryHealth < 0 || batteryHealth > 100) {
                    throw new IllegalArgumentException("Battery health must be between 0 and 100");
                }

                Connection connection = (Connection) getServletContext().getAttribute("connection");
                if (connection == null) {
                    request.setAttribute("error", "Database connection failed");
                    request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                    return;
                }

                EScooterDAO scooterDAO = new EScooterDAO(connection);
                boolean updated = scooterDAO.updateScooterBattery(scooter_id, batteryLevel, batteryHealth);

                if (updated) {
                    request.setAttribute("success", "Battery updated successfully");
                } else {
                    request.setAttribute("error", "Failed to update battery");
                }

                request.getRequestDispatcher("/jsp/scooters.jsp").forward(request, response);

            } catch (NumberFormatException e) {
                request.setAttribute("error", "Invalid battery or health format");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
            } catch (IllegalArgumentException e) {
                request.setAttribute("error", "Invalid battery data: " + e.getMessage());
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
            }

        } catch (Exception e) {
            System.err.println("Error updating battery: " + e.getMessage());
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }
}