package servlet;

import dao.TransactionDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;

/**
 * Servlet for viewing transactions (FR-06).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
@WebServlet("/transactions")
public class TransactionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            HttpSession session = request.getSession();
            String user_id = (String) session.getAttribute("user_id");

            if (user_id == null) {
                request.setAttribute("error", "User not authenticated");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            Connection connection = (Connection) getServletContext().getAttribute("connection");
            if (connection == null) {
                request.setAttribute("error", "Database connection failed");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            TransactionDAO transactionDAO = new TransactionDAO(connection);
            request.setAttribute("transactions", transactionDAO.getTransactionsByUser(user_id));
            request.getRequestDispatcher("/jsp/transactions.jsp").forward(request, response);

        } catch (Exception e) {
            System.err.println("Error fetching transactions: " + e.getMessage());
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }
}