package servlet;

import dao.EScooterDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;

/**
 * Servlet for charging scooter (FR-04).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
@WebServlet("/charge-scooter")
public class ChargeScooterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            String scooter_id = request.getParameter("scooter_id");
            if (scooter_id == null) {
                request.setAttribute("error", "Scooter not specified");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            Connection connection = (Connection) getServletContext().getAttribute("connection");
            EScooterDAO scooterDAO = new EScooterDAO(connection);
            boolean updated = scooterDAO.updateScooterStatus(scooter_id, "CHARGING");

            if (updated) {
                request.setAttribute("success", "Scooter charging started");
            } else {
                request.setAttribute("error", "Failed to start charging");
            }

            request.getRequestDispatcher("/jsp/stations.jsp").forward(request, response);

        } catch (Exception e) {
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }
}