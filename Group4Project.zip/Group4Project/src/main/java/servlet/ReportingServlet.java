package servlet;

import dao.TransactionDAO;
import dao.EScooterDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;

/**
 * Servlet for analytics and reporting (FR-06).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
@WebServlet("/reports")
public class ReportingServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            Connection connection = (Connection) getServletContext().getAttribute("connection");
            if (connection == null) {
                request.setAttribute("error", "Database connection failed");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            EScooterDAO scooterDAO = new EScooterDAO(connection);
            request.setAttribute("scooters", scooterDAO.getAllScooters());
            request.setAttribute("available_count", scooterDAO.getScootersByStatus("AVAILABLE").size());
            request.setAttribute("in_transit_count", scooterDAO.getScootersByStatus("IN_TRANSIT").size());
            
            request.getRequestDispatcher("/jsp/reports.jsp").forward(request, response);

        } catch (Exception e) {
            System.err.println("Error generating reports: " + e.getMessage());
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }
}