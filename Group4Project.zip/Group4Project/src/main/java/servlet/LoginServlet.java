package servlet;

import dao.UserDAO;
import model.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;
import java.util.UUID;

/**
 * Servlet for user login (FR-01).
 * Handles user authentication and session management.
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            if (email == null || email.isEmpty() || password == null || password.isEmpty()) {
                request.setAttribute("error", "Email and password are required");
                request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
                return;
            }

            Connection connection = (Connection) getServletContext().getAttribute("connection");
            if (connection == null) {
                request.setAttribute("error", "Database connection failed");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            UserDAO userDAO = new UserDAO(connection);
            User user = userDAO.authenticateUser(email, password);

            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("user_id", user.getUserId());
                session.setAttribute("user_name", user.getName());
                session.setAttribute("user_type", user.getUserType());
                session.setAttribute("credits", user.getCredits());
                
                response.sendRedirect("/cesc-project/jsp/dashboard.jsp");
            } else {
                request.setAttribute("error", "Invalid email or password");
                request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
            }

        } catch (Exception e) {
            System.err.println("Error in login: " + e.getMessage());
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
    }
}