package servlet;

import dao.EScooterDAO;
import dao.UsageHistoryDAO;
import dao.UserDAO;
import model.UsageHistory;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;
import java.util.UUID;

/**
 * Servlet for renting a scooter (FR-02).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
@WebServlet("/rent-scooter")
public class RentScooterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            HttpSession session = request.getSession();
            String user_id = (String) session.getAttribute("user_id");
            String scooter_id = request.getParameter("scooter_id");

            if (user_id == null || scooter_id == null) {
                request.setAttribute("error", "User not authenticated or scooter not selected");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            Connection connection = (Connection) getServletContext().getAttribute("connection");
            if (connection == null) {
                request.setAttribute("error", "Database connection failed");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            EScooterDAO scooterDAO = new EScooterDAO(connection);
            boolean updated = scooterDAO.updateScooterStatus(scooter_id, "IN_TRANSIT");

            if (updated) {
                UsageHistory usage = new UsageHistory.UsageHistoryBuilder(
                    UUID.randomUUID().toString(),
                    scooter_id,
                    user_id
                ).startTime(String.valueOf(System.currentTimeMillis())).build();

                session.setAttribute("current_rental", scooter_id);
                request.setAttribute("success", "Scooter rented successfully!");
            } else {
                request.setAttribute("error", "Failed to rent scooter");
            }

            request.getRequestDispatcher("/jsp/dashboard.jsp").forward(request, response);

        } catch (Exception e) {
            System.err.println("Error renting scooter: " + e.getMessage());
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }
}