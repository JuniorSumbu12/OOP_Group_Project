package servlet;

import dao.EScooterDAO;
import dao.UsageHistoryDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.Connection;

/**
 * Servlet for returning a scooter (FR-02).
 * 
 * @author Victory Nnalue
 * @version 1.0
 * @since 2025-11-30
 */
@WebServlet("/return-scooter")
public class ReturnScooterServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            HttpSession session = request.getSession();
            String scooter_id = (String) session.getAttribute("current_rental");
            String station_id = request.getParameter("station_id");

            if (scooter_id == null) {
                request.setAttribute("error", "No active rental");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            Connection connection = (Connection) getServletContext().getAttribute("connection");
            if (connection == null) {
                request.setAttribute("error", "Database connection failed");
                request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
                return;
            }

            EScooterDAO scooterDAO = new EScooterDAO(connection);
            boolean updated = scooterDAO.updateScooterStatus(scooter_id, "AVAILABLE");

            if (updated) {
                session.removeAttribute("current_rental");
                request.setAttribute("success", "Scooter returned successfully!");
            } else {
                request.setAttribute("error", "Failed to return scooter");
            }

            request.getRequestDispatcher("/jsp/dashboard.jsp").forward(request, response);

        } catch (Exception e) {
            System.err.println("Error returning scooter: " + e.getMessage());
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/jsp/error.jsp").forward(request, response);
        }
    }
}