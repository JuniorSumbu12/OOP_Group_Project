/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;

/**
 * Manages database connection pooling using standard jdbc
 * Provides singleton for efficient connection management
 * @author victo
 */
public class DatabaseConnection {
    private static Connection connection;
    private static final String PROPERTIES_FILE = "database.properties";
    
    private static String dbUrl;
    private static String dbUsername;
    private static String dbPassword;
    private static String dbDriver;

    static {
        loadProperties();
        loadDriver();
    }

    /**
     * Loads database configuration from properties file
     * Falls back to hardcoded defaults if file not found
     */
    private static void loadProperties() {
        Properties props = new Properties();
        
        try (InputStream input = DatabaseConnection.class.getClassLoader()
                .getResourceAsStream(PROPERTIES_FILE)) {
            
            if (input != null) {
                props.load(input);
                dbUrl = props.getProperty("db.url", "jdbc:mysql://localhost:3306/cesc_db");
                dbUsername = props.getProperty("db.username", "cst8288");
                dbPassword = props.getProperty("db.password", "cst8288");
                dbDriver = props.getProperty("db.driver", "com.mysql.cj.jdbc.Driver");
            } else {
                setDefaults();
            }
        } catch (IOException e) {
            System.err.println("Error loading database properties: " + e.getMessage());
            setDefaults();
        }
    }

    /**
     * Sets default database configuration values
     */
    private static void setDefaults() {
        dbUrl = "jdbc:mysql://localhost:3306/cesc_db";
        dbUsername = "cst8288";
        dbPassword = "cst8288";
        dbDriver = "com.mysql.cj.jdbc.Driver";
    }

    /**
     * Loads the MySQL JDBC driver
     */
    private static void loadDriver() {
        try {
            Class.forName(dbDriver);
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Gets or creates a database connection
     * @return the Connection object
     * @throws SQLException if connection fails
     */
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
        }
        return connection;
    }

    /**
     * Closes the database connection
     * @throws SQLException if closing fails
     */
    public static void closeConnection() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
            connection = null;
        }
    }

    /**
     * Checks if connection is active
     * @return true if connected, false otherwise
     */
    public static boolean isConnected() {
        try {
            return connection != null && !connection.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * Tests the database connection
     * @return true if connection successful, false otherwise
     */
    public static boolean testConnection() {
        try {
            Connection testConn = getConnection();
            if (testConn != null && !testConn.isClosed()) {
                System.out.println("✓ Database connection successful!");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("✗ Database connection failed: " + e.getMessage());
        }
        return false;
    }
}