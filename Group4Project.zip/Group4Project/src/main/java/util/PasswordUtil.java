/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;
import org.mindrot.jbcrypt.BCrypt;

/**
 ** Utility class for password hashing and verification
 * Uses BCrypt for secure password storage
 * @author victo
 */
public class PasswordUtil {
 /**
     * Hashes a plain text password using BCrypt
     * @param password the plain text password to hash
     * @return the hashed password
     */
    public static String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt());
    }

    /**
     * Verifies a plain text password against a hashed password
     * @param plainPassword the plain text password to verify
     * @param hashedPassword the previously hashed password
     * @return true if the passwords match, false otherwise
     */
    public static boolean verifyPassword(String plainPassword, String hashedPassword) {
        return BCrypt.checkpw(plainPassword, hashedPassword);
    }
    
}
