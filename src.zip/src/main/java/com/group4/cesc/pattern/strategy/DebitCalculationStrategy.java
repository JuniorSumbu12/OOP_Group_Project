/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.pattern.strategy;

/**
 * Context class that holds the current strategy.
 */
public class DebitCalculationStrategy {

    private EnergyCalculationStrategy strategy;

    public DebitCalculationStrategy(EnergyCalculationStrategy strategy) {
        this.strategy = strategy;
    }

    public void setStrategy(EnergyCalculationStrategy strategy) {
        this.strategy = strategy;
    }

    public double calculate(double minutesUsed, double distanceKm) {
        return strategy.calculateCost(minutesUsed, distanceKm);
    }
}

