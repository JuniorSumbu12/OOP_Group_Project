/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.pattern.strategy;

/**
 * Strategy interface for debit / energy cost calculation.
 */
public interface EnergyCalculationStrategy {
    double calculateCost(double minutesUsed, double distanceKm);
}

