/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.pattern.command;

import com.group4.cesc.dao.MaintenanceDAO;

public class ReplaceTireCommand implements MaintenanceCommand {

    private final String scooterId;
    private final MaintenanceDAO dao;
    private boolean completed;

    public ReplaceTireCommand(String scooterId, MaintenanceDAO dao) {
        this.scooterId = scooterId;
        this.dao = dao;
    }

    @Override
    public void execute() {
        dao.createCompletedTask(scooterId, "REPLACE_TIRE", "Tire replaced");
        completed = true;
    }

    @Override
    public boolean isCompleted() {
        return completed;
    }
}

