/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.pattern.factory;

import com.group4.cesc.model.*;

public class UserFactory {

    public static User create(String role) {
        if (role == null) return new User();
        switch (role.toUpperCase()) {
            case "SPONSOR": return new Sponsor();
            case "MAINTAINER": return new Maintainer();
            default: return new User();
        }
    }
}

