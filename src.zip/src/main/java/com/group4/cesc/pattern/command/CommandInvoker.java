/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.pattern.command;

import java.util.ArrayList;
import java.util.List;

/**
 * Invoker that stores and executes maintenance commands.
 */
public class CommandInvoker {

    private final List<MaintenanceCommand> queue = new ArrayList<>();

    public void addCommand(MaintenanceCommand cmd) {
        queue.add(cmd);
    }

    public void executeAll() {
        for (MaintenanceCommand cmd : queue) {
            cmd.execute();
        }
        queue.clear();
    }
}

