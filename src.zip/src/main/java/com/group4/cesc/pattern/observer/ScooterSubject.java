/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.pattern.observer;

import java.util.ArrayList;
import java.util.List;

public class ScooterSubject {

    private List<ScooterObserver> observers = new ArrayList<>();

    public void addObserver(ScooterObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(ScooterObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers(String scooterId, String message) {
        for (ScooterObserver obs : observers) {
            obs.update(scooterId, message);
        }
    }
}
