/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.pattern.command;

import com.group4.cesc.dao.MaintenanceDAO;

public class RechargeBatteryCommand implements MaintenanceCommand {

    private final String scooterId;
    private final MaintenanceDAO dao;
    private boolean completed;

    public RechargeBatteryCommand(String scooterId, MaintenanceDAO dao) {
        this.scooterId = scooterId;
        this.dao = dao;
    }

    @Override
    public void execute() {
        dao.createCompletedTask(scooterId, "RECHARGE_BATTERY", "Battery recharged");
        completed = true;
    }

    @Override
    public boolean isCompleted() {
        return completed;
    }
}

