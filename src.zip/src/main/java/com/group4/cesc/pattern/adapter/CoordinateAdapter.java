/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.pattern.adapter;

import com.group4.cesc.model.GeoPoint;

/**
 * Adapter that converts raw "lat,lng" String into a GeoPoint.
 */
public class CoordinateAdapter {

    public GeoPoint convert(String raw) {
        if (raw == null || !raw.contains(",")) {
            throw new IllegalArgumentException("Invalid GPS format");
        }
        String[] parts = raw.split(",");
        double lat = Double.parseDouble(parts[0].trim());
        double lng = Double.parseDouble(parts[1].trim());
        return new GeoPoint(lat, lng);
    }
}
