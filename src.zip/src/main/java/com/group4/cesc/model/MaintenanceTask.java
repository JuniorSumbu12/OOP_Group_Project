/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.model;

/**
 * Maintenance task mapped to 'maintenance_tasks' table.
 */
public class MaintenanceTask {
    private String taskId;
    private String scooterId;
    private String maintainerId;
    private String taskType;
    private String status; // PENDING, COMPLETED, etc.
    private String description;

    public MaintenanceTask() {}

    // Getters and setters
    public String getTaskId() { return taskId; }
    public void setTaskId(String taskId) { this.taskId = taskId; }

    public String getScooterId() { return scooterId; }
    public void setScooterId(String scooterId) { this.scooterId = scooterId; }

    public String getMaintainerId() { return maintainerId; }
    public void setMaintainerId(String maintainerId) { this.maintainerId = maintainerId; }

    public String getTaskType() { return taskType; }
    public void setTaskType(String taskType) { this.taskType = taskType; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}

