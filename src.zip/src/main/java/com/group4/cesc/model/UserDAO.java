/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.dao;

import com.group4.cesc.model.User;

public interface UserDAO {
    void create(User user);
    User findByEmail(String email);
}

