/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.model;

/**
 * Base User entity mapped to the 'users' table.
 */
public class User {
    private String userId;
    private String name;
    private String email;
    private String passwordHash;
    private String userType; // USER, SPONSOR, MAINTAINER
    private double credits;
    private boolean active;

    public User() {}

    // Getters and setters
    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public String getUserType() { return userType; }
    public void setUserType(String userType) { this.userType = userType; }

    public double getCredits() { return credits; }
    public void setCredits(double credits) { this.credits = credits; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
}

