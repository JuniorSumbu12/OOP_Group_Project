/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.dao;

import com.group4.cesc.model.Scooter;
import java.util.List;

public interface ScooterDAO {
    void create(Scooter scooter);
    Scooter findById(String scooterId);
    void updateLocation(String scooterId, double lat, double lng, double battery);
    java.util.List<Scooter> getAllScooters();
}

