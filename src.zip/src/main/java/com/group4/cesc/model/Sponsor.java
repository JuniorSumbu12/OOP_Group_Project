/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.model;

/**
 * Sponsor user (extra info would come from sponsors table).
 */
public class Sponsor extends User {
    // Add sponsor-specific fields if needed
}
