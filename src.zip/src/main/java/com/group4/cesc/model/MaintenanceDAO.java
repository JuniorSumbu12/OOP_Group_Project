/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.dao;

public interface MaintenanceDAO {
    void createAlert(String scooterId, String description);
    void createCompletedTask(String scooterId, String taskType, String description);
}

