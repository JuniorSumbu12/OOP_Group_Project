/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.dao.impl;

import com.group4.cesc.dao.ScooterDAO;
import com.group4.cesc.model.Scooter;
import com.group4.cesc.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySQLScooterDAO implements ScooterDAO {

    @Override
    public void create(Scooter s) {
        String sql = "INSERT INTO e_scooters (scooterId, vehicleNumber, make, model, batteryCapacity, currentBattery, status) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, s.getScooterId());
            stmt.setString(2, s.getVehicleNumber());
            stmt.setString(3, s.getMake());
            stmt.setString(4, s.getModel());
            stmt.setDouble(5, s.getBatteryCapacity());
            stmt.setDouble(6, s.getCurrentBattery());
            stmt.setString(7, s.getStatus());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Scooter findById(String id) {
        String sql = "SELECT * FROM e_scooters WHERE scooterId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Scooter s = new Scooter();
                s.setScooterId(rs.getString("scooterId"));
                s.setVehicleNumber(rs.getString("vehicleNumber"));
                s.setMake(rs.getString("make"));
                s.setModel(rs.getString("model"));
                s.setBatteryCapacity(rs.getDouble("batteryCapacity"));
                s.setCurrentBattery(rs.getDouble("currentBattery"));
                s.setHoursUsed(rs.getDouble("hoursUsed"));
                s.setLatitude(rs.getDouble("latitude"));
                s.setLongitude(rs.getDouble("longitude"));
                s.setStatus(rs.getString("status"));
                return s;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void updateLocation(String id, double lat, double lng, double battery) {
        String sql = "UPDATE e_scooters SET latitude = ?, longitude = ?, currentBattery = ? WHERE scooterId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, lat);
            stmt.setDouble(2, lng);
            stmt.setDouble(3, battery);
            stmt.setString(4, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Scooter> getAllScooters() {
        List<Scooter> list = new ArrayList<>();
        String sql = "SELECT * FROM e_scooters";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Scooter s = new Scooter();
                s.setScooterId(rs.getString("scooterId"));
                s.setVehicleNumber(rs.getString("vehicleNumber"));
                s.setMake(rs.getString("make"));
                s.setModel(rs.getString("model"));
                s.setBatteryCapacity(rs.getDouble("batteryCapacity"));
                s.setCurrentBattery(rs.getDouble("currentBattery"));
                s.setHoursUsed(rs.getDouble("hoursUsed"));
                s.setLatitude(rs.getDouble("latitude"));
                s.setLongitude(rs.getDouble("longitude"));
                s.setStatus(rs.getString("status"));
                list.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}

