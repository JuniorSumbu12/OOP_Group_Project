/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.dao.impl;

import com.group4.cesc.dao.UserDAO;
import com.group4.cesc.model.User;
import com.group4.cesc.util.DBConnection;

import java.sql.*;

/**
 * MySQL implementation of UserDAO.
 */
public class MySQLUserDAO implements UserDAO {

    @Override
    public void create(User user) {
        String sql = "INSERT INTO users (userId, name, email, password_hash, userType, credits, active) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUserId());
            stmt.setString(2, user.getName());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getPasswordHash());
            stmt.setString(5, user.getUserType());
            stmt.setDouble(6, user.getCredits());
            stmt.setBoolean(7, user.isActive());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public User findByEmail(String email) {
        String sql = "SELECT * FROM users WHERE email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User u = new User();
                u.setUserId(rs.getString("userId"));
                u.setName(rs.getString("name"));
                u.setEmail(rs.getString("email"));
                u.setPasswordHash(rs.getString("password_hash"));
                u.setUserType(rs.getString("userType"));
                u.setCredits(rs.getDouble("credits"));
                u.setActive(rs.getBoolean("active"));
                return u;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

