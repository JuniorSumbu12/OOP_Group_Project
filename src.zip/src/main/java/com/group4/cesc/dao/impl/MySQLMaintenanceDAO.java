/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.dao.impl;

import com.group4.cesc.dao.MaintenanceDAO;
import com.group4.cesc.util.DBConnection;

import java.sql.*;
import java.util.UUID;

public class MySQLMaintenanceDAO implements MaintenanceDAO {

    @Override
    public void createAlert(String scooterId, String description) {
        String sql = "INSERT INTO maintenance_tasks (taskId, scooterId, taskType, status, description) " +
                     "VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, UUID.randomUUID().toString());
            stmt.setString(2, scooterId);
            stmt.setString(3, "ALERT");
            stmt.setString(4, "PENDING");
            stmt.setString(5, description);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void createCompletedTask(String scooterId, String taskType, String description) {
        String sql = "INSERT INTO maintenance_tasks (taskId, scooterId, taskType, status, description) " +
                     "VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, UUID.randomUUID().toString());
            stmt.setString(2, scooterId);
            stmt.setString(3, taskType);
            stmt.setString(4, "COMPLETED");
            stmt.setString(5, description);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
