/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.service;

import com.group4.cesc.pattern.strategy.*;
import com.group4.cesc.pattern.observer.*;
import com.group4.cesc.dao.MaintenanceDAO;
import com.group4.cesc.dao.impl.MySQLMaintenanceDAO;
import com.group4.cesc.model.ScooterStatus;

/**
 * Service using Strategy + Observer for maintenance logic.
 */
public class MaintenanceService {

    private final ScooterSubject subject = new ScooterSubject();
    private final MaintenanceDAO maintenanceDAO = new MySQLMaintenanceDAO();

    public MaintenanceService() {
        // Add console observer
        subject.addObserver(new MaintenanceAlertObserver());
    }

    public void checkScooterStatus(
            String scooterId,
            double batteryPercent,
            double hoursUsed,
            ScooterStatus status) {

        if (batteryPercent < 20) {
            String msg = "Battery low (" + batteryPercent + "%)";
            maintenanceDAO.createAlert(scooterId, msg);
            subject.notifyObservers(scooterId, msg);
        }

        if (hoursUsed > 500) {
            String msg = "High usage hours (" + hoursUsed + ")";
            maintenanceDAO.createAlert(scooterId, msg);
            subject.notifyObservers(scooterId, msg);
        }

        if (status == ScooterStatus.INACTIVE) {
            String msg = "Scooter inactive - inspection required";
            maintenanceDAO.createAlert(scooterId, msg);
            subject.notifyObservers(scooterId, msg);
        }
    }

    public double calculateDebit(boolean isStudent, double minutes, double km) {
        DebitCalculationStrategy context;
        if (isStudent) {
            context = new DebitCalculationStrategy(new StudentDebitStrategy());
        } else {
            context = new DebitCalculationStrategy(new StandardEnergyStrategy());
        }
        return context.calculate(minutes, km);
    }
}
