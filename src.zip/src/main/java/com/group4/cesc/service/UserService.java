/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.service;

import com.group4.cesc.dao.UserDAO;
import com.group4.cesc.dao.impl.MySQLUserDAO;
import com.group4.cesc.model.User;

import java.util.UUID;

/**
 * Handles user registration and login logic.
 */
public class UserService {

    private final UserDAO userDAO = new MySQLUserDAO();

    public void register(User user, String rawPassword) {
        user.setUserId(UUID.randomUUID().toString());
        // For CST8288, we can keep plain or put a simple hash placeholder
        user.setPasswordHash(rawPassword);
        user.setCredits(0.0);
        user.setActive(true);
        userDAO.create(user);
    }

    public User login(String email, String rawPassword) {
        User user = userDAO.findByEmail(email);
        if (user != null && user.getPasswordHash().equals(rawPassword) && user.isActive()) {
            return user;
        }
        return null;
    }
}

