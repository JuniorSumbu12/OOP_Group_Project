/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.controller;

import com.group4.cesc.model.ScooterStatus;
import com.group4.cesc.service.MaintenanceService;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;


public class MaintenanceCheckServlet extends HttpServlet {

    private final MaintenanceService maintenanceService = new MaintenanceService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String scooterId = req.getParameter("id");
        double battery = Double.parseDouble(req.getParameter("battery"));
        double hours = Double.parseDouble(req.getParameter("hours"));
        ScooterStatus status = ScooterStatus.valueOf(req.getParameter("status"));

        maintenanceService.checkScooterStatus(scooterId, battery, hours, status);

        resp.getWriter().println("Maintenance check completed for scooter " + scooterId);
    }
}
