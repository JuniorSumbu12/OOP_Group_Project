/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.controller;

import com.group4.cesc.dao.impl.MySQLMaintenanceDAO;
import com.group4.cesc.pattern.command.*;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;


public class ExecuteMaintenanceServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String scooterId = req.getParameter("scooterId");
        String action = req.getParameter("action"); // "tire" or "battery"

        MySQLMaintenanceDAO dao = new MySQLMaintenanceDAO();
        CommandInvoker invoker = new CommandInvoker();

        if ("tire".equalsIgnoreCase(action)) {
            invoker.addCommand(new ReplaceTireCommand(scooterId, dao));
        } else if ("battery".equalsIgnoreCase(action)) {
            invoker.addCommand(new RechargeBatteryCommand(scooterId, dao));
        }

        invoker.executeAll();
        resp.sendRedirect("maintenance.jsp");
    }
}

