/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.group4.cesc.controller;

import com.group4.cesc.dao.impl.MySQLScooterDAO;
import com.group4.cesc.model.GeoPoint;
import com.group4.cesc.pattern.adapter.CoordinateAdapter;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;


public class UpdateLocationServlet extends HttpServlet {

    private final MySQLScooterDAO scooterDAO = new MySQLScooterDAO();
    private final CoordinateAdapter adapter = new CoordinateAdapter();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String scooterId = req.getParameter("scooterId");
        String gps = req.getParameter("gps"); // "lat,lng"
        String batteryStr = req.getParameter("battery");

        GeoPoint point = adapter.convert(gps);
        double battery = Double.parseDouble(batteryStr);

        scooterDAO.updateLocation(scooterId, point.getLatitude(), point.getLongitude(), battery);

        resp.sendRedirect("dashboard.jsp");
    }
}

