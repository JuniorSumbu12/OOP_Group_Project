package com.group4.cesc.controller;

import com.group4.cesc.model.User;
import com.group4.cesc.pattern.factory.UserFactory;
import com.group4.cesc.service.UserService;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class RegisterServlet extends HttpServlet {

    private final UserService userService = new UserService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String role = req.getParameter("role");

        User user = UserFactory.create(role);
        user.setName(name);
        user.setEmail(email);
        user.setUserType(role.toUpperCase());

        // CRITICAL: Save password into User object
        user.setPasswordHash(password);

        // Save user into DB
        userService.register(user, password);

        resp.sendRedirect("login.jsp");
    }
}
